@extends('layout.laypetugas')

@section('menu')
  <ul class="sidebar-menu">
    <li class="menu-header ">Main</li>
        <li class="dropdown">
          <a href="/petugas" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
        </li>
    <li class="menu-header">Data</li>
        <li class="dropdown">
          <a href="/datapasien" class="nav-link"><i data-feather="users"></i><span>Data Pasien</span></a>
        </li>
        <li class="dropdown">
          <a href="/dataklinis" class="nav-link"><i data-feather="check-circle"></i><span>Data Informasi Klinis</span></a>
        </li>
        <li class="dropdown">
          <a href="/datapenunjang" class="nav-link"><i data-feather="check-circle"></i><span>Data Pemeriksaan Penunjang</span></a>
        </li>
        <li class="dropdown active">
          <a href="#" class="nav-link"><i data-feather="check-circle"></i><span>Data Riwayat Perjalanan</span></a>
        </li>
        <li class="dropdown">
          <a href="/datapaparan" class="nav-link"><i data-feather="check-circle"></i><span>Data Faktor Kontak / Paparan</span></a>
        </li>
    <li class="menu-header">Laporan</li>
        <li class="dropdown">
          <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="file-text"></i><span>Laporan</span></a>
          <ul class="dropdown-menu">
            <li><a class="nav-link" href="/datalaporanperhari">per Hari</a></li>
            <li><a class="nav-link" href="/datalaporanperbulan">per Bulan</a></li>
          </ul>
        </li>
  </ul>
@endsection

<?php 
    $no = 1;
    $sta = array('Ya','Tidak','Tidak Tahu');
  ?>

@section('content')
  <section class="section">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h4>Data Riwayat Perjalanan</h4>
            </div>
            <div class="card-body">
              <a href="#" class="btn btn-icon icon-left btn-primary" data-toggle="modal" data-target="#exampleModalCenter"  style="margin-bottom: 10px;"><i class="fas fa-plus-square"></i> Tambah Data Riwayat Perjalanan</a>
              <div class="table-responsive">
                <table class="table table-striped table-hover" id="save-stage" style="width: 100%;">
                  <thead>
                      <tr>
                          <th>NIK</th>
                          <th>Nama</th>
                          <th>Gender</th>
                          <th>Pekerjaan</th>
                          <th>Aksi</th>
                      </tr>
                  </thead>
                  <tbody>
                      @foreach($data as $dat)
                      <tr>
                          <td>{{$dat->NIK}}</td>
                          <td>{{$dat->NAMA}}</td>
                          <td>{{$dat->GENDER}}</td>
                          <td>{{$dat->PEKERJAAN}}</td>
                          <td style="width: 150px;">
                              <!-- <a href="/peserta:data={{$dat->NIK}}" class="btn btn-info"><i class="feather icon-info"></i></a>  -->
                              <a href="/riper:det={{$dat->NIK}}" class="btn btn-info"><i class="fa fa-info-circle"></i></a>
                              <a href="/riper:del={{$dat->NIK}}" class="btn btn-danger" onclick="return(confirm('Anda Yakin ?'));"><i class="fa fa-trash"></i></a>
                          </td>
                      </tr>
                      @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
  </section>


  <div class="modal fade" id="exampleModalCenter" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Tambah Pemeriksaan Penunjang</h5>
        </div>
        <form action="{{url('/add_riper')}}" method="post" enctype="multipart/form-data">
        {{csrf_field()}}

        <div class="modal-body">
            <div class="col-md-12">
                <div class="row">
                    <table style="width: 100%;">
                        <tr>
                          <td>NOMOR INDUK KEPENDUDUKAN</td>
                          <td>:</td>
                          <td style="width: 50%;">
                            <select name="nik" class="form-control select2" style="width: 100%;" required="">
                              <option></option>>
                              @foreach($pas as $pa)
                                <option value="{{$pa->NIK}}">{{$pa->NAMA}} / {{$pa->NIK}}</option>
                              @endforeach
                            </select>
                          </td>
                        </tr>
                    </table>
                    <br><br>
                    @foreach($idra as $ida)
                        <input class="form-control" type="hidden" name="idaa" value="{{$ida->PERJ1_ID+1}}" required="">
                        <input class="form-control" type="hidden" name="idab" value="{{$ida->PERJ1_ID+2}}" required="">  
                    @endforeach
                    <table border="" style="width: 100%;margin-top: 10px;">
                        <tr>
                            <td colspan="3" style="width: 75%;padding: 5px;">Dalam 14 hari sebelum sakit, apakah memiliki riwayat perjalanan dari luar negeri ?</td>
                            <td colspan="1" style="width: 25%;padding: 5px;"> 
                              <select name="sta" id="sta1" class="form-control" required="">
                                <option></option>
                                @foreach($sta as $st)
                                <option>{{$st}}</option>
                                @endforeach
                              </select>
                            </td>
                        </tr>
                        <tr style="text-align: center;background-color: lightgrey">
                            <td>Negara</td>
                            <td>Kota</td>
                            <td>Tgl Perjalanan</td>
                            <td>Tgl Tiba</td>
                        </tr>
                        <tr style="text-align: center;">
                            <td><input class="form-control" type="text" name="neg" placeholder="Indonesia"></td>
                            <td><input class="form-control" type="text" name="kot" placeholder="Jakarta"></td>
                            <td><input class="form-control" type="date" name="tgp"></td>
                            <td><input class="form-control" type="date" name="tgt"></td>
                        </tr>
                        <tr style="text-align: center;">
                            <td><input class="form-control" type="text" name="nega" placeholder="Indonesia"></td>
                            <td><input class="form-control" type="text" name="kota" placeholder="Jakarta"></td>
                            <td><input class="form-control" type="date" name="tgpa"></td>
                            <td><input class="form-control" type="date" name="tgta"></td>
                        </tr>
                    </table>
                      @foreach($idrb as $idb)
                          <input class="form-control" type="hidden" name="idac" value="{{$idb->PERJ2_ID+1}}" required="">
                          <input class="form-control" type="hidden" name="idad" value="{{$idb->PERJ2_ID+2}}" required="">  
                      @endforeach
                    <table border="" style="width: 100%;margin-top: 20px;">
                        <tr>
                            <td colspan="3" style="width: 75%;padding: 5px;">Dalam 14 hari sebelum sakit, apakah memiliki riwayat perjalanan dari area transmisi lokal ?</td>
                            <td colspan="1" style="width: 25%;padding: 5px;"> 
                                <select name="sta2" id="sta1" class="form-control" required="">
                                    <option></option>
                                    @foreach($sta as $st)
                                    <option>{{$st}}</option>
                                    @endforeach
                                </select>
                            </td>
                        </tr>
                        <tr style="text-align: center;background-color: lightgrey">
                            <td>Provinsi</td>
                            <td>Kota</td>
                            <td>Tgl Perjalanan</td>
                            <td>Tgl Tiba</td>
                        </tr>
                        <tr style="text-align: center;">
                            <td><input class="form-control" type="text" name="prob" placeholder="Jawa Timur"></td>
                            <td><input class="form-control" type="text" name="kotb" placeholder="Jakarta"></td>
                            <td><input class="form-control" type="date" name="tgpb"></td>
                            <td><input class="form-control" type="date" name="tgtb"></td>
                        </tr>
                        <tr style="text-align: center;">
                            <td><input class="form-control" type="text" name="proc" placeholder="Jawa Timur"></td>
                            <td><input class="form-control" type="text" name="kotc" placeholder="Jakarta"></td>
                            <td><input class="form-control" type="date" name="tgpc"></td>
                            <td><input class="form-control" type="date" name="tgtc"></td>
                        </tr>
                    </table>
                        @foreach($idrc as $idc)
                            <input class="form-control" type="hidden" name="idae" value="{{$idc->PERJ3_ID+1}}" required=""> 
                        @endforeach
                    <table border="" style="width: 100%;margin-top: 20px;">
                        <tr>
                            <td style="width: 50%;padding: 5px;">Dalam 14 hari sebelum sakit, apakah memiliki riwayat perjalanan ke area transmisi lokal ?</td>
                            <td colspan="1" style="width: 50%;padding: 5px;"> 
                                <select name="sta3" id="sta1" class="form-control" required="">
                                    <option></option>
                                    @foreach($sta as $st)
                                    <option>{{$st}}</option>
                                    @endforeach
                                </select>
                            </td>
                        </tr>
                        <tr style="text-align: center;background-color: lightgrey">
                            <td>Provinsi</td>
                            <td>Kota</td>
                        <tr style="text-align: center;">
                            <td><input class="form-control" type="text" name="prod" placeholder="Jawa Timur"></td>
                            <td><input class="form-control" type="text" name="kotd" placeholder="Jakarta"></td>
                        </tr>
                    </table>
                        @foreach($idrb as $idb)
                            <input class="form-control" type="hidden" name="idaf" value="{{$idb->PERJ2_ID+1}}" required="">
                            <input class="form-control" type="hidden" name="idag" value="{{$idb->PERJ2_ID+2}}" required="">  
                        @endforeach
                    <table border="" style="width: 100%;margin-top: 20px;">
                        <tr>
                            <td colspan="4" style="width: 80%;padding: 5px;">Dalam 14 hari sebelum sakit, apakah memiliki kontak dengan kasus suspek / problable COVID-19 ?</td>
                            <td colspan="1" style="width: 20%;padding: 5px;"> 
                                <select name="sta4" id="sta1" class="form-control" required="" style="width: 150px;" >
                                    <option></option>
                                    @foreach($sta as $st)
                                    <option>{{$st}}</option>
                                    @endforeach
                                </select>
                            </td>
                        </tr>
                        <tr style="text-align: center;background-color: lightgrey">
                            <td>Nama</td>
                            <td>Alamat</td>
                            <td>Hubungan</td>
                            <td>Tgl Kontak Pertama</td>
                            <td>Tgl Kontak Terakhir</td>
                        </tr>
                        <tr style="text-align: center;">
                            <td><input class="form-control" type="text" name="nama" placeholder="Ahmad"></td>
                            <td><input class="form-control" type="text" name="alae" placeholder="Jl. Mawar" style="width: 160px;"></td>
                            <td><input class="form-control" type="text" name="huba" placeholder="Teman"></td>
                            <td><input class="form-control" type="date" name="tka" style="width: 160px;"></td>
                            <td><input class="form-control" type="date" name="tkb" style="width: 160px;"></td>
                        </tr>
                        <tr style="text-align: center;">
                            <td><input class="form-control" type="text" name="namb" placeholder="Ahmad"></td>
                            <td><input class="form-control" type="text" name="alaf" placeholder="Jl. Mawar" style="width: 160px;"></td>
                            <td><input class="form-control" type="text" name="hubb" placeholder="Teman"></td>
                            <td><input class="form-control" type="date" name="tkc" style="width: 160px;"></td>
                            <td><input class="form-control" type="date" name="tkd" style="width: 160px;"></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button  class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
            <button class="btn btn-primary"><i class="fa fa-check-circle"></i> Simpan</button>
        </div>
        </form>
      </div>
    </div>
  </div>

@endsection