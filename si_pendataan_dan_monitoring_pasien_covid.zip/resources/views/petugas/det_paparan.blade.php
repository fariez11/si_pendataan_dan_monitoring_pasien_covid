@extends('layout.laypetugas')

@section('menu')
  <ul class="sidebar-menu">
    <li class="menu-header ">Main</li>
        <li class="dropdown">
          <a href="/petugas" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
        </li>
    <li class="menu-header">Data</li>
        <li class="dropdown">
          <a href="/datapasien" class="nav-link"><i data-feather="users"></i><span>Data Pasien</span></a>
        </li>
        <li class="dropdown">
          <a href="/dataklinis" class="nav-link"><i data-feather="check-circle"></i><span>Data Informasi Klinis</span></a>
        </li>
        <li class="dropdown">
          <a href="/datapenunjang" class="nav-link"><i data-feather="check-circle"></i><span>Data Pemeriksaan Penunjang</span></a>
        </li>
        <li class="dropdown">
          <a href="/datariper" class="nav-link"><i data-feather="check-circle"></i><span>Data Riwayat Perjalanan</span></a>
        </li>
        <li class="dropdown active">
          <a href="/datapaparan" class="nav-link"><i data-feather="check-circle"></i><span>Data Faktor Kontak / Paparan</span></a>
        </li>
    <li class="menu-header">Laporan</li>
        <li class="dropdown">
          <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="file-text"></i><span>Laporan</span></a>
          <ul class="dropdown-menu">
            <li><a class="nav-link" href="/datalaporanperhari">per Hari</a></li>
            <li><a class="nav-link" href="/datalaporanperbulan">per Bulan</a></li>
          </ul>
        </li>
  </ul>
@endsection

<?php 
    $no = 1;
    $sta = array('Ya','Tidak','Tidak Tahu');
  ?>

@section('content')
  <section class="section">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h4>Detail Data Paparan</h4>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <style type="text/css">
                        table tr td{
                            padding: 5px;
                        }
                    </style>
                <table border  style="width: 100%;">
                    <thead>
                        <tr>
                            <td colspan="5" style="width: 85%;padding: 5px;">Dalam 14 hari sebelum sakit, apakah memiliki kontak erat dengan kasus konfirmasi dan probable COVID-19 ?</td>
                            <td colspan="1"> 
                                @foreach($spa as $sp){{$sp->STATUS}}@endforeach
                            </td>
                        </tr>
                        <tr>
                            <td colspan="6"> <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#tambahppr"><i class="fas fa-plus-square"> </i> Tambah Data</button></td>
                        </tr>
                        <tr style="text-align: center;">
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>Hubungan</th>
                            <th>Tgl Kontak Awal</th>
                            <th style="width: 100px;">Tgl Kontak Akhir</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($pa as $dat)
                        <tr>
                            <td>{{$dat->NAMA}}</td>
                            <td>{{$dat->ALAMAT}}</td>
                            <td>{{$dat->HUBUNGAN}}</td>
                            <td>{{$dat->TGL_AWAL}}</td>
                            <td>{{$dat->TGL_AKHIR}}</td>
                            <td style="width: 70px;text-align: center;">
                                <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#editPaparan{{$dat->PA1_ID}}"><i class="fa fa-edit"></i></a>
                                <a href="/dppr:del={{$dat->PA1_ID}}" class="btn btn-danger" onclick="return(confirm('Anda Yakin ?'));"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                <br>
                <table border="" style="margin-top: 20px;">
                    @foreach($pb as $pb)
                    <tr>
                        <td>
                            Apakah pasien termasuk cluster ISPA berat (demam dan pneumonia membutuhkan perawatan Rumah Sakit) yang tidak diketahui penyebabnya ?
                        </td>
                        <td style="width: 30%;padding: 5px;"> 
                            {{$pb->ISPA}}
                        </td>
                    </tr>
                    <tr>
                        <td rowspan="2">
                            Apakah pasien memiliki hewan peliharaan ? <br><br>

                            Jika iya sebutkan 
                        </td>
                        <td > 
                            {{$pb->ST_HEWAN}}
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <?php 
                                if($pb->ANJING == null){

                                }else{
                                    echo " Anjing,";
                                }

                                if($pb->KUCING == null){

                                }else{
                                    echo " Kucing,";
                                }
                            ?>
                            {{$pb->S_HEWAN}}
                        </td> 
                    </tr>
                    <tr>
                        <td>Apakah pasien seorang petugas kesehatan ?</td>
                        <td> 
                            {{$pb->PET_KES}}
                       </td>
                    </tr>
                    <tr>
                        <td>
                            Jika Ya, alat pelindung di (APD) apa yang dipakai saat melakukan perawatan pada pasien suspek / probable / konfirmasi ?
                        </td>
                        <td>
                        <?php
                            if($pb->TAPD == 'Tidak'){ 
                                if($pb->APD1 == null){

                                }else{
                                    echo " Gown,";
                                }

                                if($pb->APD2 == null){

                                }else{
                                    echo " Masker Medis,";
                                }

                                if($pb->APD3 == null){

                                }else{
                                    echo " Sarung Tangan,";
                                }

                                if($pb->APD4 == null){

                                }else{
                                    echo " FFP3,";
                                }

                                if($pb->APD5 == null){

                                }else{
                                    echo " Masker NIOSH-N95, AN EU STANDARD FFP2,";
                                }

                                if($pb->APD6 == null){

                                }else{
                                    echo " Kacamata Pelindung (google),";
                                }

                            }else{
                                echo "Tidak Memakai APD";
                            }
                        ?>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Apakah melakukan prosedur yang menimbulkan erosol ? 
                        </td>
                        <td>
                            {{$pb->PROSEDUR}}
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            Lain-lain, sebutkan :<br>
                            - {{$pb->LAINNYA}}
                        </td>   
                    </tr>
                    @endforeach
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
  </section>


  <div class="modal fade" id="tambahppr" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Tambah Data Paparan</h5>
        </div>

        <form action="{{url('/add_dppr')}}" method="post" enctype="multipart/form-data">
        {{csrf_field()}}
          <div class="modal-body">

              @foreach($ipa as $ipa)
                  <input class="form-control" type="hidden" name="ipa" value="{{$ipa->PA1_ID+1}}" required="">
              @endforeach
              @foreach($spa as $nid)
                  <input class="form-control" type="hidden" name="nik" value="{{$nid->NIK}}" required="">
              @endforeach

              <div class="form-group">
                  <label>Nama</label>
                  <input type="text" name="nam" class="form-control" placeholder="Ahmad" autocomplete="off" required="">
              </div>
              <div class="form-group">
                  <label>Alamat</label>
                  <input type="text" name="ala" class="form-control" placeholder="Jl. Mawar " autocomplete="off" required="">
              </div>
              <div class="form-group">
                  <label>Hubungan</label>
                  <input type="text" name="hub" class="form-control" placeholder="Teman Kerja" autocomplete="off" required="">
              </div>
              <div class="form-group">
                  <label>Tanggal Kontak Awal</label>
                  <input type="date" name="tgp" class="form-control" autocomplete="off" required="">
              </div>
              <div class="form-group">
                  <label>Tanggal Kontak Akhir</label>
                  <input type="date" name="tgt" class="form-control" autocomplete="off" required="">
              </div>
          </div>
          <div class="modal-footer">
              <button  class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
              <button class="btn btn-primary"><i class="fa fa-check-circle"></i> Simpan</button>
          </div>
      </form>

      </div>
    </div>
  </div>

  @foreach($pa as $ed)
  <div class="modal fade" id="editPaparan{{$ed->PA1_ID}}" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog modal-md" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Info Pasien</h5>
        </div>

        <?php 
            $id = $ed->PA1_ID;
            $upd = DB::SELECT("select*from paparan1 where PA1_ID = '$id'");
        ?>
        @foreach($upd as $ed)
        <form action="/dppr:upd={{$ed->PA1_ID}}" method="post" enctype="multipart/form-data">
            {{csrf_field()}}
        <div class="modal-body">
            <div class="form-group">
                <label>Nama</label>
                <input type="text" name="nam" class="form-control" value="{{$ed->NAMA}}" autocomplete="off" required="">
            </div>
            <div class="form-group">
                <label>Alamat</label>
                <input type="text" name="ala" class="form-control" value="{{$ed->ALAMAT}}" autocomplete="off" required="">
            </div>
            <div class="form-group">
                <label>Hubungan</label>
                <input type="text" name="hub" class="form-control" value="{{$ed->HUBUNGAN}}" autocomplete="off" required="">
            </div>
            <div class="form-group">
                <label>Tanggal Kontak Pertama</label>
                <input type="date" name="tgp" class="form-control" value="{{$ed->TGL_AWAL}}" autocomplete="off" required="">
            </div>
            <div class="form-group">
                <label>Tanggal Kontak Terakhir</label>
                <input type="date" name="tgt" class="form-control" value="{{$ed->TGL_AKHIR}}" autocomplete="off" required="">
            </div>
        </div>
        <div class="modal-footer">
            <button  class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
            <button class="btn btn-primary"><i class="fa fa-check-circle"></i> Ubah</button>
        </div>
        </form>
        @endforeach

      </div>
    </div>
  </div>
  @endforeach

  @endsection