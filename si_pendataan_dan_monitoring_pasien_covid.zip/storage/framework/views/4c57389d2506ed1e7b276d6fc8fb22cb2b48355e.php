

<?php $__env->startSection('menu'); ?>
  <ul class="sidebar-menu">
    <li class="menu-header">Main</li>
    <li class="dropdown">
      <a href="/admin" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
    </li>
    <li class="menu-header">Data</li>
    <li class="dropdown">
      <a href="/datapengguna" class="nav-link"><i data-feather="users"></i><span>Data Pengguna</span></a>
    </li>
    <li class="dropdown">
      <a href="/datakota" class="nav-link"><i data-feather="navigation-2"></i><span>Data Kota / Kabupaten</span></a>
    </li>
    <li class="dropdown">
      <a href="/datakecamatan" class="nav-link"><i data-feather="navigation"></i><span>Data Kecamatan</span></a>
    </li>
    <li class="dropdown">
      <a href="/datakelurahan" class="nav-link"><i data-feather="map-pin"></i><span>Data Kelurahan</span></a>
    </li>
    <li class="dropdown active">
      <a href="#" class="nav-link"><i data-feather="home"></i><span>Data Tempat Pemeriksaan</span></a>
    </li>
  </ul>
<?php $__env->stopSection(); ?>
<?php 
    $no = 1;

    $lev = array('Owner','Petugas');
?>

<?php $__env->startSection('content'); ?>
  <section class="section">
      <div class="row">
        <div class="col-7">
          <div class="card">
            <div class="card-header">
              <h4>Data Tempat Pemeriksaan</h4>
            </div>
            <div class="card-body">
              <a href="#" class="btn btn-icon icon-left btn-primary" data-toggle="modal" data-target="#exampleModalCenter"  style="margin-bottom: 10px;"><i class="fas fa-plus-square"></i> Tambah Data Tempat Pemeriksaan</a>
              <div class="table-responsive">
                <table class="table table-striped table-hover" id="save-stage" style="width: 100%;">
                  <thead>
                      <tr>
                          <th>#</th>
                          <th>Tempat Pemeriksaan</th>                          
                          <th>Aksi</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <td style="text-align: center;"><?php echo e($no++); ?></td>
                          <td><?php echo e($dat->NAMA_TEMPAT); ?></td>
                          <td style="width: 150px;"> 
                              <a href="#" class="btn btn-icon btn-outline-warning" data-toggle="modal" data-target="#editTmp<?php echo e($dat->TMP_ID); ?>"><i class="far fa-edit"></i></a> 
                              <a href="/tmp:del=<?php echo e($dat->TMP_ID); ?>" class="btn btn-outline-danger btn-icon" onclick="return(confirm('Anda Yakin ?'));"><i class="fas fa-trash"></i></a>
                          </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
  </section>

  <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Tambah Tempat Pemeriksaan</h5>
        </div>
        <form action="<?php echo e(url('/add_tmp')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

            <div class="modal-body">
              <div class="row">
                <div class="col-md-12">
                  <?php $__currentLoopData = $idt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <input type="hidden" name="idt" value="<?php echo e($id->TMP_ID+1); ?>" readonly="">
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">
                        <label for="pwd">Nama Tempat Pemeriksaan</label>
                        <input class="form-control" type="text" name="nama" placeholder="nama tempat pemeriksaan" autocomplete="off" required="">
                    </div>
                    
                </div>
              </div>
            </div>
            <div class="modal-footer bg-whitesmoke br">
              <button type="button" class="btn btn-danger" data-dismiss="modal"> <i class="far fa-times-circle"></i> Batal</button>
              <button class="btn btn-primary"><i class="far fa-check-circle"></i> Simpan</button>
            </div>
        </form>
      </div>
    </div>
  </div>


  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="editTmp<?php echo e($ed->TMP_ID); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Edit Tempat Pemeriksaan</h5>
        </div>
        <?php 
            $id = $ed->TMP_ID;
            $edit = DB::SELECT("select*from tempat_pemeriksaan where TMP_ID = '$id'");
        ?>
        <?php $__currentLoopData = $edit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/tmp:upd=<?php echo e($upd->TMP_ID); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

            <div class="modal-body">             
              <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="pwd">Nama Tempat Pemeriksaan</label>
                        <input class="form-control" type="text" name="nama" value="<?php echo e($upd->NAMA_TEMPAT); ?>" autocomplete="off" required="">
                    </div>
                </div>
              </div>
            </div>
            <div class="modal-footer bg-whitesmoke br">
              <button type="button" class="btn btn-danger" data-dismiss="modal"> <i class="far fa-times-circle"></i> Batal</button>
              <button class="btn btn-primary"><i class="far fa-check-circle"></i> Ubah</button>
            </div>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\si_pendataan_dan_monitoring_pasien_covid\resources\views//admin/dt_tmp.blade.php ENDPATH**/ ?>