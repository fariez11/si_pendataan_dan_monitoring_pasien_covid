

<?php $__env->startSection('menu'); ?>
 <ul class="sidebar-menu">
    <li class="menu-header active">Main</li>
        <li class="dropdown active">
          <a href="#" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
        </li>
    <li class="menu-header">Laporan</li>
        <li class="dropdown">
          <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="file-text"></i><span>Laporan</span></a>
          <ul class="dropdown-menu">
            <!-- <li><a class="nav-link" href="/datalaporan">Rekap</a></li> -->
            <li><a class="nav-link" href="/odatalaporanperhari">per Hari</a></li>
            <li><a class="nav-link" href="/odatalaporanperbulan">per Bulan</a></li>
          </ul>
        </li>
  </ul>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
  

<?php $__env->stopSection(); ?>    
    
<?php echo $__env->make('layout.layowner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pmpc\resources\views//owner/home.blade.php ENDPATH**/ ?>