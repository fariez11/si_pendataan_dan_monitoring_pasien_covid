

<?php $__env->startSection('menu'); ?>
 <ul class="sidebar-menu">
    <li class="menu-header active">Main</li>
    <li class="dropdown active">
      <a href="#" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
    </li>
    <li class="menu-header">Data</li>
    <li class="dropdown">
      <a href="/datapengguna" class="nav-link"><i data-feather="users"></i><span>Data Pengguna</span></a>
    </li>
    <li class="dropdown">
      <a href="/datakota" class="nav-link"><i data-feather="navigation-2"></i><span>Data Kota / Kabupaten</span></a>
    </li>
    <li class="dropdown">
      <a href="/datakecamatan" class="nav-link"><i data-feather="navigation"></i><span>Data Kecamatan</span></a>
    </li>
    <li class="dropdown">
      <a href="/datakelurahan" class="nav-link"><i data-feather="map-pin"></i><span>Data Kelurahan</span></a>
    </li>
    <li class="dropdown">
      <a href="/datatempat" class="nav-link"><i data-feather="home"></i><span>Data Tempat Pemeriksaan</span></a>
    </li>
  </ul>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
  <section class="section">
    <div class="row ">

      <?php $__currentLoopData = $jpeng; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-xl-3 col-lg-6">
          <div class="card l-bg-cyan">
            <div class="card-statistic-3">
              <div class="card-icon card-icon-large"><i class="fa fa-users"></i></div>
              <div class="card-content">
                <h4 class="card-title">Jumlah Pengguna</h4>
                
                <h5><?php echo e($jum->jum); ?> Pengguna</h5>
                <br><br>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php $__currentLoopData = $jkec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-xl-3 col-lg-6">
          <div class="card l-bg-cyan">
            <div class="card-statistic-3">
              <div class="card-icon card-icon-large"><i class="fa fa-map-marker-alt"></i></div>
              <div class="card-content">
                <h4 class="card-title">Jumlah Kecamatan</h4>
                
                <h5><?php echo e($jum->jum); ?> Kecamatan</h5>
                <br><br>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      <?php $__currentLoopData = $jkel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-xl-3 col-lg-6">
          <div class="card l-bg-cyan">
            <div class="card-statistic-3">
              <div class="card-icon card-icon-large"><i class="fa fa-map-pin"></i></div>
              <div class="card-content">
                <h4 class="card-title">Jumlah Kelurahan</h4>
                
                <h5><?php echo e($jum->jum); ?> Kelurahan</h5>
                <br><br>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      <?php $__currentLoopData = $jtmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-xl-3 col-lg-6">
          <div class="card l-bg-cyan">
            <div class="card-statistic-3">
              <div class="card-icon card-icon-large"><i class="fa fa-clinic-medical"></i></div>
              <div class="card-content">
                <h4 class="card-title">Jumlah Tempat</h4>
                
                <h5><?php echo e($jum->jum); ?> Tempat</h5>
                <br><br>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </div>
    <br><br><br><br><br><br><br><br><br><br><br>
  </section>

<?php $__env->stopSection(); ?>    
    
<?php echo $__env->make('layout.layadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pmpc\resources\views//admin/home.blade.php ENDPATH**/ ?>