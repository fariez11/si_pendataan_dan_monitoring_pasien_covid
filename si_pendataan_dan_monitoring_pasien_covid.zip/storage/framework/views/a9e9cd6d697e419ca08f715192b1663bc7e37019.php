

<?php $__env->startSection('menu'); ?>
  <ul class="sidebar-menu">
    <li class="menu-header ">Main</li>
        <li class="dropdown">
          <a href="/petugas" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
        </li>
    <li class="menu-header">Data</li>
        <li class="dropdown">
          <a href="/datapasien" class="nav-link"><i data-feather="users"></i><span>Data Pasien</span></a>
        </li>
        <li class="dropdown">
          <a href="/dataklinis" class="nav-link"><i data-feather="check-circle"></i><span>Data Informasi Klinis</span></a>
        </li>
        <li class="dropdown">
          <a href="/datapenunjang" class="nav-link"><i data-feather="check-circle"></i><span>Data Pemeriksaan Penunjang</span></a>
        </li>
        <li class="dropdown active">
          <a href="#" class="nav-link"><i data-feather="check-circle"></i><span>Data Riwayat Perjalanan</span></a>
        </li>
        <li class="dropdown">
          <a href="/datapaparan" class="nav-link"><i data-feather="check-circle"></i><span>Data Faktor Kontak / Paparan</span></a>
        </li>
    <li class="menu-header">Laporan</li>
        <li class="dropdown">
          <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="file-text"></i><span>Laporan</span></a>
          <ul class="dropdown-menu">
            <li><a class="nav-link" href="/datalaporanperhari">per Hari</a></li>
            <li><a class="nav-link" href="/datalaporanperbulan">per Bulan</a></li>
          </ul>
        </li>
  </ul>
<?php $__env->stopSection(); ?>

<?php 
    $no = 1;
    $sta = array('Ya','Tidak','Tidak Tahu');
  ?>

<?php $__env->startSection('content'); ?>
  <section class="section">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h4>Data Riwayat Perjalanan</h4>
            </div>
            <div class="card-body">
              <a href="#" class="btn btn-icon icon-left btn-primary" data-toggle="modal" data-target="#exampleModalCenter"  style="margin-bottom: 10px;"><i class="fas fa-plus-square"></i> Tambah Data Riwayat Perjalanan</a>
              <div class="table-responsive">
                <table class="table table-striped table-hover" id="save-stage" style="width: 100%;">
                  <thead>
                      <tr>
                          <th>NIK</th>
                          <th>Nama</th>
                          <th>Gender</th>
                          <th>Pekerjaan</th>
                          <th>Aksi</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <td><?php echo e($dat->NIK); ?></td>
                          <td><?php echo e($dat->NAMA); ?></td>
                          <td><?php echo e($dat->GENDER); ?></td>
                          <td><?php echo e($dat->PEKERJAAN); ?></td>
                          <td style="width: 150px;">
                              <!-- <a href="/peserta:data=<?php echo e($dat->NIK); ?>" class="btn btn-info"><i class="feather icon-info"></i></a>  -->
                              <a href="/riper:det=<?php echo e($dat->NIK); ?>" class="btn btn-info"><i class="fa fa-info-circle"></i></a>
                              <a href="/riper:del=<?php echo e($dat->NIK); ?>" class="btn btn-danger" onclick="return(confirm('Anda Yakin ?'));"><i class="fa fa-trash"></i></a>
                          </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
  </section>


  <div class="modal fade" id="exampleModalCenter" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Tambah Pemeriksaan Penunjang</h5>
        </div>
        <form action="<?php echo e(url('/add_riper')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>


        <div class="modal-body">
            <div class="col-md-12">
                <div class="row">
                    <table style="width: 100%;">
                        <tr>
                          <td>NOMOR INDUK KEPENDUDUKAN</td>
                          <td>:</td>
                          <td style="width: 50%;">
                            <select name="nik" class="form-control select2" style="width: 100%;" required="">
                              <option></option>>
                              <?php $__currentLoopData = $pas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pa->NIK); ?>"><?php echo e($pa->NAMA); ?> / <?php echo e($pa->NIK); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </td>
                        </tr>
                    </table>
                    <br><br>
                    <?php $__currentLoopData = $idra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input class="form-control" type="hidden" name="idaa" value="<?php echo e($ida->PERJ1_ID+1); ?>" required="">
                        <input class="form-control" type="hidden" name="idab" value="<?php echo e($ida->PERJ1_ID+2); ?>" required="">  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <table border="" style="width: 100%;margin-top: 10px;">
                        <tr>
                            <td colspan="3" style="width: 75%;padding: 5px;">Dalam 14 hari sebelum sakit, apakah memiliki riwayat perjalanan dari luar negeri ?</td>
                            <td colspan="1" style="width: 25%;padding: 5px;"> 
                              <select name="sta" id="sta1" class="form-control" required="">
                                <option></option>
                                <?php $__currentLoopData = $sta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option><?php echo e($st); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                            </td>
                        </tr>
                        <tr style="text-align: center;background-color: lightgrey">
                            <td>Negara</td>
                            <td>Kota</td>
                            <td>Tgl Perjalanan</td>
                            <td>Tgl Tiba</td>
                        </tr>
                        <tr style="text-align: center;">
                            <td><input class="form-control" type="text" name="neg" placeholder="Indonesia"></td>
                            <td><input class="form-control" type="text" name="kot" placeholder="Jakarta"></td>
                            <td><input class="form-control" type="date" name="tgp"></td>
                            <td><input class="form-control" type="date" name="tgt"></td>
                        </tr>
                        <tr style="text-align: center;">
                            <td><input class="form-control" type="text" name="nega" placeholder="Indonesia"></td>
                            <td><input class="form-control" type="text" name="kota" placeholder="Jakarta"></td>
                            <td><input class="form-control" type="date" name="tgpa"></td>
                            <td><input class="form-control" type="date" name="tgta"></td>
                        </tr>
                    </table>
                      <?php $__currentLoopData = $idrb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <input class="form-control" type="hidden" name="idac" value="<?php echo e($idb->PERJ2_ID+1); ?>" required="">
                          <input class="form-control" type="hidden" name="idad" value="<?php echo e($idb->PERJ2_ID+2); ?>" required="">  
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <table border="" style="width: 100%;margin-top: 20px;">
                        <tr>
                            <td colspan="3" style="width: 75%;padding: 5px;">Dalam 14 hari sebelum sakit, apakah memiliki riwayat perjalanan dari area transmisi lokal ?</td>
                            <td colspan="1" style="width: 25%;padding: 5px;"> 
                                <select name="sta2" id="sta1" class="form-control" required="">
                                    <option></option>
                                    <?php $__currentLoopData = $sta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option><?php echo e($st); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                        <tr style="text-align: center;background-color: lightgrey">
                            <td>Provinsi</td>
                            <td>Kota</td>
                            <td>Tgl Perjalanan</td>
                            <td>Tgl Tiba</td>
                        </tr>
                        <tr style="text-align: center;">
                            <td><input class="form-control" type="text" name="prob" placeholder="Jawa Timur"></td>
                            <td><input class="form-control" type="text" name="kotb" placeholder="Jakarta"></td>
                            <td><input class="form-control" type="date" name="tgpb"></td>
                            <td><input class="form-control" type="date" name="tgtb"></td>
                        </tr>
                        <tr style="text-align: center;">
                            <td><input class="form-control" type="text" name="proc" placeholder="Jawa Timur"></td>
                            <td><input class="form-control" type="text" name="kotc" placeholder="Jakarta"></td>
                            <td><input class="form-control" type="date" name="tgpc"></td>
                            <td><input class="form-control" type="date" name="tgtc"></td>
                        </tr>
                    </table>
                        <?php $__currentLoopData = $idrc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input class="form-control" type="hidden" name="idae" value="<?php echo e($idc->PERJ3_ID+1); ?>" required=""> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <table border="" style="width: 100%;margin-top: 20px;">
                        <tr>
                            <td style="width: 50%;padding: 5px;">Dalam 14 hari sebelum sakit, apakah memiliki riwayat perjalanan ke area transmisi lokal ?</td>
                            <td colspan="1" style="width: 50%;padding: 5px;"> 
                                <select name="sta3" id="sta1" class="form-control" required="">
                                    <option></option>
                                    <?php $__currentLoopData = $sta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option><?php echo e($st); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                        <tr style="text-align: center;background-color: lightgrey">
                            <td>Provinsi</td>
                            <td>Kota</td>
                        <tr style="text-align: center;">
                            <td><input class="form-control" type="text" name="prod" placeholder="Jawa Timur"></td>
                            <td><input class="form-control" type="text" name="kotd" placeholder="Jakarta"></td>
                        </tr>
                    </table>
                        <?php $__currentLoopData = $idrb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input class="form-control" type="hidden" name="idaf" value="<?php echo e($idb->PERJ2_ID+1); ?>" required="">
                            <input class="form-control" type="hidden" name="idag" value="<?php echo e($idb->PERJ2_ID+2); ?>" required="">  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <table border="" style="width: 100%;margin-top: 20px;">
                        <tr>
                            <td colspan="4" style="width: 80%;padding: 5px;">Dalam 14 hari sebelum sakit, apakah memiliki kontak dengan kasus suspek / problable COVID-19 ?</td>
                            <td colspan="1" style="width: 20%;padding: 5px;"> 
                                <select name="sta4" id="sta1" class="form-control" required="" style="width: 150px;" >
                                    <option></option>
                                    <?php $__currentLoopData = $sta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option><?php echo e($st); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                        <tr style="text-align: center;background-color: lightgrey">
                            <td>Nama</td>
                            <td>Alamat</td>
                            <td>Hubungan</td>
                            <td>Tgl Kontak Pertama</td>
                            <td>Tgl Kontak Terakhir</td>
                        </tr>
                        <tr style="text-align: center;">
                            <td><input class="form-control" type="text" name="nama" placeholder="Ahmad"></td>
                            <td><input class="form-control" type="text" name="alae" placeholder="Jl. Mawar" style="width: 160px;"></td>
                            <td><input class="form-control" type="text" name="huba" placeholder="Teman"></td>
                            <td><input class="form-control" type="date" name="tka" style="width: 160px;"></td>
                            <td><input class="form-control" type="date" name="tkb" style="width: 160px;"></td>
                        </tr>
                        <tr style="text-align: center;">
                            <td><input class="form-control" type="text" name="namb" placeholder="Ahmad"></td>
                            <td><input class="form-control" type="text" name="alaf" placeholder="Jl. Mawar" style="width: 160px;"></td>
                            <td><input class="form-control" type="text" name="hubb" placeholder="Teman"></td>
                            <td><input class="form-control" type="date" name="tkc" style="width: 160px;"></td>
                            <td><input class="form-control" type="date" name="tkd" style="width: 160px;"></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button  class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
            <button class="btn btn-primary"><i class="fa fa-check-circle"></i> Simpan</button>
        </div>
        </form>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.laypetugas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\si_pendataan_dan_monitoring_pasien_covid\resources\views//petugas/dt_riperjalanan.blade.php ENDPATH**/ ?>