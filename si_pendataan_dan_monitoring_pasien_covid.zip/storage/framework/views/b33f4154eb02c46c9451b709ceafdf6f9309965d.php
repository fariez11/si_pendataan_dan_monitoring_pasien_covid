

<?php $__env->startSection('menu'); ?>
  <ul class="sidebar-menu">
    <li class="menu-header ">Main</li>
        <li class="dropdown">
          <a href="/petugas" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
        </li>
    <li class="menu-header">Data</li>
        <li class="dropdown">
          <a href="/datapasien" class="nav-link"><i data-feather="users"></i><span>Data Pasien</span></a>
        </li>
        <li class="dropdown">
          <a href="/dataklinis" class="nav-link"><i data-feather="check-circle"></i><span>Data Informasi Klinis</span></a>
        </li>
        <li class="dropdown">
          <a href="/datapenunjang" class="nav-link"><i data-feather="check-circle"></i><span>Data Pemeriksaan Penunjang</span></a>
        </li>
        <li class="dropdown">
          <a href="/datariper" class="nav-link"><i data-feather="check-circle"></i><span>Data Riwayat Perjalanan</span></a>
        </li>
        <li class="dropdown active">
          <a href="/datapaparan" class="nav-link"><i data-feather="check-circle"></i><span>Data Faktor Kontak / Paparan</span></a>
        </li>
    <li class="menu-header">Laporan</li>
        <li class="dropdown">
          <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="file-text"></i><span>Laporan</span></a>
          <ul class="dropdown-menu">
            <li><a class="nav-link" href="/datalaporanperhari">per Hari</a></li>
            <li><a class="nav-link" href="/datalaporanperbulan">per Bulan</a></li>
          </ul>
        </li>
  </ul>
<?php $__env->stopSection(); ?>

<?php 
    $no = 1;
    $sta = array('Ya','Tidak','Tidak Tahu');
  ?>

<?php $__env->startSection('content'); ?>
  <section class="section">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h4>Detail Data Paparan</h4>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <style type="text/css">
                        table tr td{
                            padding: 5px;
                        }
                    </style>
                <table border  style="width: 100%;">
                    <thead>
                        <tr>
                            <td colspan="5" style="width: 85%;padding: 5px;">Dalam 14 hari sebelum sakit, apakah memiliki kontak erat dengan kasus konfirmasi dan probable COVID-19 ?</td>
                            <td colspan="1"> 
                                <?php $__currentLoopData = $spa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($sp->STATUS); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="6"> <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#tambahppr"><i class="fas fa-plus-square"> </i> Tambah Data</button></td>
                        </tr>
                        <tr style="text-align: center;">
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>Hubungan</th>
                            <th>Tgl Kontak Awal</th>
                            <th style="width: 100px;">Tgl Kontak Akhir</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($dat->NAMA); ?></td>
                            <td><?php echo e($dat->ALAMAT); ?></td>
                            <td><?php echo e($dat->HUBUNGAN); ?></td>
                            <td><?php echo e($dat->TGL_AWAL); ?></td>
                            <td><?php echo e($dat->TGL_AKHIR); ?></td>
                            <td style="width: 70px;text-align: center;">
                                <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#editPaparan<?php echo e($dat->PA1_ID); ?>"><i class="fa fa-edit"></i></a>
                                <a href="/dppr:del=<?php echo e($dat->PA1_ID); ?>" class="btn btn-danger" onclick="return(confirm('Anda Yakin ?'));"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <br>
                <table border="" style="margin-top: 20px;">
                    <?php $__currentLoopData = $pb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            Apakah pasien termasuk cluster ISPA berat (demam dan pneumonia membutuhkan perawatan Rumah Sakit) yang tidak diketahui penyebabnya ?
                        </td>
                        <td style="width: 30%;padding: 5px;"> 
                            <?php echo e($pb->ISPA); ?>

                        </td>
                    </tr>
                    <tr>
                        <td rowspan="2">
                            Apakah pasien memiliki hewan peliharaan ? <br><br>

                            Jika iya sebutkan 
                        </td>
                        <td > 
                            <?php echo e($pb->ST_HEWAN); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <?php 
                                if($pb->ANJING == null){

                                }else{
                                    echo " Anjing,";
                                }

                                if($pb->KUCING == null){

                                }else{
                                    echo " Kucing,";
                                }
                            ?>
                            <?php echo e($pb->S_HEWAN); ?>

                        </td> 
                    </tr>
                    <tr>
                        <td>Apakah pasien seorang petugas kesehatan ?</td>
                        <td> 
                            <?php echo e($pb->PET_KES); ?>

                       </td>
                    </tr>
                    <tr>
                        <td>
                            Jika Ya, alat pelindung di (APD) apa yang dipakai saat melakukan perawatan pada pasien suspek / probable / konfirmasi ?
                        </td>
                        <td>
                        <?php
                            if($pb->TAPD == 'Tidak'){ 
                                if($pb->APD1 == null){

                                }else{
                                    echo " Gown,";
                                }

                                if($pb->APD2 == null){

                                }else{
                                    echo " Masker Medis,";
                                }

                                if($pb->APD3 == null){

                                }else{
                                    echo " Sarung Tangan,";
                                }

                                if($pb->APD4 == null){

                                }else{
                                    echo " FFP3,";
                                }

                                if($pb->APD5 == null){

                                }else{
                                    echo " Masker NIOSH-N95, AN EU STANDARD FFP2,";
                                }

                                if($pb->APD6 == null){

                                }else{
                                    echo " Kacamata Pelindung (google),";
                                }

                            }else{
                                echo "Tidak Memakai APD";
                            }
                        ?>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Apakah melakukan prosedur yang menimbulkan erosol ? 
                        </td>
                        <td>
                            <?php echo e($pb->PROSEDUR); ?>

                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            Lain-lain, sebutkan :<br>
                            - <?php echo e($pb->LAINNYA); ?>

                        </td>   
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
  </section>


  <div class="modal fade" id="tambahppr" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Tambah Data Paparan</h5>
        </div>

        <form action="<?php echo e(url('/add_dppr')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

          <div class="modal-body">

              <?php $__currentLoopData = $ipa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ipa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <input class="form-control" type="hidden" name="ipa" value="<?php echo e($ipa->PA1_ID+1); ?>" required="">
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $spa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <input class="form-control" type="hidden" name="nik" value="<?php echo e($nid->NIK); ?>" required="">
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <div class="form-group">
                  <label>Nama</label>
                  <input type="text" name="nam" class="form-control" placeholder="Ahmad" autocomplete="off" required="">
              </div>
              <div class="form-group">
                  <label>Alamat</label>
                  <input type="text" name="ala" class="form-control" placeholder="Jl. Mawar " autocomplete="off" required="">
              </div>
              <div class="form-group">
                  <label>Hubungan</label>
                  <input type="text" name="hub" class="form-control" placeholder="Teman Kerja" autocomplete="off" required="">
              </div>
              <div class="form-group">
                  <label>Tanggal Kontak Awal</label>
                  <input type="date" name="tgp" class="form-control" autocomplete="off" required="">
              </div>
              <div class="form-group">
                  <label>Tanggal Kontak Akhir</label>
                  <input type="date" name="tgt" class="form-control" autocomplete="off" required="">
              </div>
          </div>
          <div class="modal-footer">
              <button  class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
              <button class="btn btn-primary"><i class="fa fa-check-circle"></i> Simpan</button>
          </div>
      </form>

      </div>
    </div>
  </div>

  <?php $__currentLoopData = $pa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="editPaparan<?php echo e($ed->PA1_ID); ?>" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog modal-md" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Info Pasien</h5>
        </div>

        <?php 
            $id = $ed->PA1_ID;
            $upd = DB::SELECT("select*from paparan1 where PA1_ID = '$id'");
        ?>
        <?php $__currentLoopData = $upd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/dppr:upd=<?php echo e($ed->PA1_ID); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

        <div class="modal-body">
            <div class="form-group">
                <label>Nama</label>
                <input type="text" name="nam" class="form-control" value="<?php echo e($ed->NAMA); ?>" autocomplete="off" required="">
            </div>
            <div class="form-group">
                <label>Alamat</label>
                <input type="text" name="ala" class="form-control" value="<?php echo e($ed->ALAMAT); ?>" autocomplete="off" required="">
            </div>
            <div class="form-group">
                <label>Hubungan</label>
                <input type="text" name="hub" class="form-control" value="<?php echo e($ed->HUBUNGAN); ?>" autocomplete="off" required="">
            </div>
            <div class="form-group">
                <label>Tanggal Kontak Pertama</label>
                <input type="date" name="tgp" class="form-control" value="<?php echo e($ed->TGL_AWAL); ?>" autocomplete="off" required="">
            </div>
            <div class="form-group">
                <label>Tanggal Kontak Terakhir</label>
                <input type="date" name="tgt" class="form-control" value="<?php echo e($ed->TGL_AKHIR); ?>" autocomplete="off" required="">
            </div>
        </div>
        <div class="modal-footer">
            <button  class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
            <button class="btn btn-primary"><i class="fa fa-check-circle"></i> Ubah</button>
        </div>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.laypetugas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pmpc\resources\views//petugas/det_paparan.blade.php ENDPATH**/ ?>