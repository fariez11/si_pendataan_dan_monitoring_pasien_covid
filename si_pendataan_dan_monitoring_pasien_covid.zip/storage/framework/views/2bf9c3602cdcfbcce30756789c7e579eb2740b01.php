

<?php $__env->startSection('menu'); ?>
 <ul class="sidebar-menu">
    <li class="menu-header">Main</li>
        <li class="dropdown">
          <a href="#" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
        </li>
    <li class="menu-header">Laporan</li>
        <li class="dropdown active">
          <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="file-text"></i><span>Laporan</span></a>
          <ul class="dropdown-menu">
            <!-- <li><a class="nav-link" href="/datalaporan">Rekap</a></li> -->
            <li class="active"><a class="nav-link" href="/odatalaporanperhari">per Hari</a></li>
            <li><a class="nav-link" href="/odatalaporanperbulan">per Bulan</a></li>
          </ul>
        </li>
  </ul>
<?php $__env->stopSection(); ?>

<?php 
    $no = 1;
    $gen = array('Laki-laki','Perempuan');
    $kat = array('Suspek','Kasus Probabel','Kasus Konfirmasi','Kontak Erat','ODR');
?>

<?php $__env->startSection('content'); ?>
  <section class="section">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h4>Laporan per Hari</h4>
            </div>
            <div class="card-body">


              <div class="table-responsive">
                <table border="" style="width: 100%;">
                    <tr style="background: lightgrey;text-align: center;font-weight: bold;">
                        <td style="padding: 10px;">No</td>
                        <td colspan="3"> STATUS</td>
                        <td> JUMLAH PER HARI</td>
                    </tr>
                    <tr style="background-color: lightgrey;">
                        <td style="text-align: center;"><b>1</b></td>
                        <td colspan="4"><b>DATA KASUS SUSPEK</b></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah kasus suspek</td>
                        <td style="text-align: center;"><?php $__currentLoopData = $ka1a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ka1a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($ka1a->jum); ?> orang <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah kasus probable</td>
                        <td style="text-align: center;"><?php $__currentLoopData = $ka1b; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ka1b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($ka1b->jum); ?> orang <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah kasus suspek diisolasi</td>
                        <td style="text-align: center;"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah kasus suspek discarder</td>
                        <td style="text-align: center;"></td>
                    </tr>
                    <tr style="background-color: lightgrey;">
                        <td style="text-align: center;"><b>2</b></td>
                        <td colspan="4"><b>DATA KASUS KONFIRMASI</b></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah kasus konfirmasi</td>
                        <td style="text-align: center;"><?php $__currentLoopData = $ka2a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ka2a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($ka2a->jum); ?> orang <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah kasus konfirmasi bergejala</td>
                        <td style="text-align: center;"><?php $__currentLoopData = $ka2b; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ka2b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($ka2b->jum); ?> orang <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah kasus konfirmasi tanpa gejala</td>
                        <td style="text-align: center;"><?php $__currentLoopData = $ka2c; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ka2c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($ka2c->jum); ?> orang <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah kasus konfirmasi perjalanan (impor)</td>
                        <td style="text-align: center;"><?php $__currentLoopData = $ka2d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ka2d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($ka2d->jum); ?> orang <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah kasus konfirmasi kontak *)</td>
                        <td style="text-align: center;"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah kasus konfirmasi tidak ada riwayat perjalanan atau kontak erat **)</td>
                        <td style="text-align: center;"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Selesai isolasi kasus konfirmasi hari ini</td>
                        <td style="text-align: center;"><?php $__currentLoopData = $ka2g; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ka2g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($ka2g->jum); ?> orang <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                    </tr>
                    <tr style="background-color: lightgrey;">
                        <td style="text-align: center;"><b>3</b></td>
                        <td colspan="4"><b>DATA PEMANTAUAN KONTAK ERAT</b></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah kasus konfirmasi dilakukan pelacakan kontak erat</td>
                        <td style="text-align: center;"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah kontak erat baru</td>
                        <td style="text-align: center;"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah kontak erat menjadi kasus suspek</td>
                        <td style="text-align: center;"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah kontak erat menjadi kasus konfirmasi</td>
                        <td style="text-align: center;"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah kontak erat mangkir pemantauan</td>
                        <td style="text-align: center;"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah kontak erat discarder</td>
                        <td style="text-align: center;"></td>
                    </tr>
                    <tr style="background-color: lightgrey;">
                        <td style="text-align: center;"><b>4</b></td>
                        <td colspan="4"><b>DATA KASUS MENINGGAL</b></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Meninggal karena RT-PCR (+)</td>
                        <td style="text-align: center;"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Meninggal Probabel</td>
                        <td style="text-align: center;"><?php $__currentLoopData = $ka4b; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ka4b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($ka4b->jum); ?> orang <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                    </tr>
                    <tr style="background-color: lightgrey;">
                        <td style="text-align: center;"><b>5</b></td>
                        <td colspan="4"><b>PEMERIKSAAN RT-PCR</b></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah kasus diambil specimen/swab</td>
                        <td style="text-align: center;"><?php $__currentLoopData = $ka5a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ka5a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($ka5a->jum); ?> orang <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                    </tr>
                    <tr style="background-color: lightgrey;">
                        <td style="text-align: center;"><b>6</b></td>
                        <td colspan="4"><b>SURVEILANS SEROLOGI</b></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah rapid test</td>
                        <td style="text-align: center;"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah rapid test reaktif</td>
                        <td style="text-align: center;"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah reaktif periksa RTPCR</td>
                        <td style="text-align: center;"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="3">Jumlah reaktif dengan RTPCR(+)</td>
                        <td style="text-align: center;"></td>
                    </tr>
                    <tr style="background-color: lightgrey;">
                        <td style="text-align: center;"><b>7</b></td>
                        <td colspan="4"><b>ISOLASI / KARANTINA HARI INI</b></td>
                    </tr>
                    <tr style="text-align: center;">
                        <td></td>
                        <td style="padding: 10px;">KLASIFIKASI</td>
                        <td>RS.RUJUKAN</td>
                        <td>RS.DARURAT</td>
                        <td>ISOLASI / KARANTINA MANDIRI</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>Jumlah kasus suspek + kasus probabel</td>
                        <td></td>
                        <td style="text-align: center;"></td>
                        <td style="text-align: center;"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>Jumlah kasus konfirmasi</td>
                        <td></td>
                        <td style="text-align: center;"></td>
                        <td style="text-align: center;"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>Jumlah erat sedang dipantau</td>
                        <td></td>
                        <td style="text-align: center;"></td>
                        <td style="text-align: center;"></td>
                    </tr>
                </table>
              </div>
            </div>
            <div class="card-footer" style="color: black;font-weight: bold;">
                Keterangan: <br>
                - *) jumlah kontak erat menjadi konfirmasi + jumlah kasus konfirmasi dengan faktor resiko kontak yang tidak berasal dari pelacakan kontak erat <br>
                - **) jumlah kasus diambil spesimen/swab - (jumlah konfirmasi perjalanan + jumlah konfirmasi kontak)
            </div>
          </div>
        </div>
      </div>
  </section>

<?php $__env->stopSection(); ?>    
    
<?php echo $__env->make('layout.layowner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pmpc\resources\views//owner/lp_perhari.blade.php ENDPATH**/ ?>