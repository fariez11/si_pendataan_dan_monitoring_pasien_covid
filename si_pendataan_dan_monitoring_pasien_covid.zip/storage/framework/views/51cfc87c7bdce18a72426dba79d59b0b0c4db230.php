

<?php $__env->startSection('menu'); ?>
  <ul class="sidebar-menu">
    <li class="menu-header ">Main</li>
        <li class="dropdown">
          <a href="/petugas" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
        </li>
    <li class="menu-header">Data</li>
        <li class="dropdown">
          <a href="/datapasien" class="nav-link"><i data-feather="users"></i><span>Data Pasien</span></a>
        </li>
        <li class="dropdown">
          <a href="/dataklinis" class="nav-link"><i data-feather="check-circle"></i><span>Data Informasi Klinis</span></a>
        </li>
        <li class="dropdown">
          <a href="/datapenunjang" class="nav-link"><i data-feather="check-circle"></i><span>Data Pemeriksaan Penunjang</span></a>
        </li>
        <li class="dropdown active">
          <a href="#" class="nav-link"><i data-feather="check-circle"></i><span>Data Riwayat Perjalanan</span></a>
        </li>
        <li class="dropdown">
          <a href="/datapaparan" class="nav-link"><i data-feather="check-circle"></i><span>Data Faktor Kontak / Paparan</span></a>
        </li>
    <li class="menu-header">Laporan</li>
        <li class="dropdown">
          <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="file-text"></i><span>Laporan</span></a>
          <ul class="dropdown-menu">
            <li><a class="nav-link" href="/datalaporanperhari">per Hari</a></li>
            <li><a class="nav-link" href="/datalaporanperbulan">per Bulan</a></li>
          </ul>
        </li>
  </ul>
<?php $__env->stopSection(); ?>
<?php 
    $no = 1;
    $sta = array('Ya','Tidak','Tidak Tahu');
  ?>

<?php $__env->startSection('content'); ?>
  <section class="section">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h4>Data Riwayat Perjalanan</h4>
            </div>
            <div class="card-body table-border-style">
                <div class="row">            
                    <div class="col-md-12" style="margin: -20px 0px 30px 0px;">
                        <center><label><b>Data Diri</b></label></center>
                        <style type="text/css">
                           .jarak{
                            padding-right: 20px;
                          }
                        </style>
                        <?php $__currentLoopData = $pas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <table>
                           <tr>
                               <td>Nama</td>
                               <td>:</td>
                               <td><?php echo e($det->NAMA); ?></td>
                               <td class="jarak"></td>
                               <td>Tgl Lahir</td>
                               <td>:</td>
                               <td><?php echo date('d M Y',strtotime($det->TGL_LAHIR)); ?></td>
                               <td class="jarak"></td>
                               <td>Umur</td>
                               <td>:</td>
                               <td><?php echo e($det->UMUR); ?> tahun</td>
                               <td class="jarak"></td>
                               <td>Gender</td>
                               <td>:</td>
                               <td><?php echo e($det->GENDER); ?></td>
                           </tr>
                           <tr>
                               <td>Pekerjaan</td>
                               <td>:</td>
                               <td><?php echo e($det->PEKERJAAN); ?></td>
                               <td class="jarak"></td>
                               <td>Alamat</td>
                               <td>:</td>
                               <td><?php echo e($det->ALAMAT); ?> Rt.<?php echo e($det->RT); ?>/Rw.<?php echo e($det->RW); ?></td>
                               <td class="jarak"></td>
                               <td>Desa</td>
                               <td>:</td>
                               <td>Desa <?php echo e($det->KELURAHAN); ?></td>
                               <td class="jarak"></td>
                               <td>Kecamatan</td>
                               <td>:</td>
                               <td><?php echo e($det->NAMA_KEC); ?></td>
                           </tr>
                           <tr>
                               <td>Kab / Kota</td>
                               <td>:</td>
                               <td><?php echo e($det->NAMA_KOTA); ?></td>
                               <td class="jarak"></td>
                               <td>No Ponsel</td>
                               <td>:</td>
                               <td><?php echo e($det->NO_TELP); ?></td>
                               <td class="jarak"></td>
                               <td>Kategori</td>
                               <td>:</td>
                               <td><?php echo e($det->KAT); ?></td>
                           </tr>
                       </table>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br>
                    <a href="/datariper" class="btn btn-success btn-block"><i class="fas fa-arrow-circle-left"></i> Kembali</a>
                    </div>    
                    <hr>
                    <style type="text/css">
                        table tr td{
                            padding: 5px;
                        }
                    </style>
                    <div class="col-md-12">
                        <table border="" style="width: 100%;margin-top: 10px;">
                            <tr>
                                <td colspan="5">
                                <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#tambaha"><i class="fas fa-plus-square"></i> Tambah Data</button>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="4" style="width: 85%;padding: 5px;">Dalam 14 hari sebelum sakit, apakah memiliki riwayat perjalanan dari luar negeri ?</td>
                                <td colspan="1" style="width: 15%;padding: 5px;"> 
                                  <?php $__currentLoopData = $st1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($s1->STATUS); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                            <tr style="text-align: center;background-color: lightgrey">
                                <td style="width: 120px;">Negara</td>
                                <td style="width: 120px;">Kota</td>
                                <td style="width: 50px;">Tgl Perjalanan</td>
                                <td style="width: 50px;">Tgl Tiba</td>
                                <td>Aksi</td>
                            </tr>
                            <?php $__currentLoopData = $rpa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="text-align: center;">
                                <td><?php echo e($d1->NEGARA); ?></td>
                                <td><?php echo e($d1->KOTA); ?></td>
                                <td><?php echo date('d M Y',strtotime($d1->TGL_PERJ)); ?></td>
                                <td><?php echo date('d M Y',strtotime($d1->TGL_TIBA)); ?> </td>
                                <td><a href="#" class="btn btn-warning" data-toggle="modal" data-target="#editRipera<?php echo e($d1->PERJ1_ID); ?>"><i class="fa fa-edit"></i></a>
                                <a href="/ripa:del=<?php echo e($d1->PERJ1_ID); ?>" class="btn btn-danger" onclick="return(confirm('Anda Yakin ?'));"><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>


                        <table border="" style="width: 100%;margin-top: 20px;">
                            <tr>
                                <td colspan="5">
                                <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#tambahb"><i class="fas fa-plus-square"></i> Tambah Data</button>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="4" style="width: 85%;padding: 5px;">Dalam 14 hari sebelum sakit, apakah memiliki riwayat perjalanan dari area transmisi lokal ?</td>
                                <td colspan="1" style="width: 15%;padding: 5px;"> 
                                  <?php $__currentLoopData = $st2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($s2->STATUS); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                            <tr style="text-align: center;background-color: lightgrey">
                                <td style="width: 120px;">Provinsi</td>
                                <td style="width: 120px;">Kota</td>
                                <td style="width: 50px;">Tgl Perjalanan</td>
                                <td style="width: 50px;">Tgl Tiba</td>
                                <td>Aksi</td>
                            </tr>
                            <?php $__currentLoopData = $rpb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="text-align: center;">
                                <td><?php echo e($d2->PROV); ?></td>
                                <td><?php echo e($d2->KOTA); ?></td>
                                <td>
                                  <?php 
                                    if($d2->TGL_PERJ == null){

                                    }else{ 
                                       echo date('d M Y',strtotime($d2->TGL_PERJ));
                                    } 
                                  ?>
                                  </td>
                                <td><?php 
                                    if($d2->TGL_TIBA == null){

                                    }else{ 
                                       echo date('d M Y',strtotime($d2->TGL_TIBA));
                                    } 
                                  ?></td>
                                <td><a href="#" class="btn btn-warning" data-toggle="modal" data-target="#editRiperb<?php echo e($d2->PERJ2_ID); ?>"><i class="fa fa-edit"></i></a>
                                <a href="/ripb:del=<?php echo e($d2->PERJ2_ID); ?>" class="btn btn-danger" onclick="return(confirm('Anda Yakin ?'));"><i class="fa fa-trash"></i></a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>

                        <table border="" style="width: 100%;margin-top: 20px;">
                            <tr>
                                <td colspan="5">
                                <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#tambahc"><i class="fas fa-plus-square"></i> Tambah Data</button>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2" style="width: 85%;padding: 5px;">Dalam 14 hari sebelum sakit, apakah memiliki riwayat perjalanan ke area transmisi lokal ?</td>
                                <td style="width: 15%;padding: 5px;"> 
                                  <?php $__currentLoopData = $st3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($s3->STATUS); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                            <tr style="text-align: center;background-color: lightgrey">
                                <td>Provinsi</td>
                                <td>Kota</td>
                                <td>Aksi</td>
                            </tr>
                            <?php $__currentLoopData = $rpc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="text-align: center;">
                                <td><?php echo e($d3->PROV); ?></td>
                                <td><?php echo e($d3->KOTA); ?></td>
                                <td><a href="#" class="btn btn-warning" data-toggle="modal" data-target="#editRiperc<?php echo e($d3->PERJ3_ID); ?>"><i class="fa fa-edit"></i></a>
                                <a href="/ripc:del=<?php echo e($d3->PERJ3_ID); ?>" class="btn btn-danger" onclick="return(confirm('Anda Yakin ?'));"><i class="fa fa-trash"></i></a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>

                        <table border="" style="width: 100%;margin-top: 20px;">
                            <tr>
                                <td colspan="5">
                                <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#tambahd"><i class="fas fa-plus-square"></i> Tambah Data</button>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="4" style="width: 85%;padding: 5px;">Dalam 14 hari sebelum sakit, apakah memiliki kontak dengan kasus suspek/ probable COVID-19</td>
                                <td colspan="1" style="width: 15%;padding: 5px;"> 
                                  <?php $__currentLoopData = $st4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($s4->STATUS); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                            <tr style="text-align: center;background-color: lightgrey">
                                <td style="width: 140px;">Nama</td>
                                <td style="width: 130px;">Alamat</td>
                                <td style="width: 110px;">Hubungan</td>
                                <!-- <td style="width: 50px;">Tgl Kontak </td> -->
                                <td>Tgl Kontak</td>
                                <td>Aksi</td>
                            </tr>
                            <?php $__currentLoopData = $rpd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="text-align: center;">
                                <td><?php echo e($d4->NAMA); ?></td>
                                <td><?php echo e($d4->ALAMAT); ?></td>
                                <td><?php echo e($d4->HUBUNGAN); ?></td>
                                <td>
                                  <?php 
                                    if($d4->TGL_AWAL == null){

                                    }else{  
                                        echo date('d M Y',strtotime($d4->TGL_AWAL)); ?> s/d <?php echo date('d M Y',strtotime($d4->TGL_AKHIR)); 
                                    }
                                  ?>
                                  </td>
                                <td><a href="#" class="btn btn-warning" data-toggle="modal" data-target="#editRiperd<?php echo e($d4->PERJ4_ID); ?>"><i class="fa fa-edit"></i></a>
                                <a href="/ripd:del=<?php echo e($d4->PERJ4_ID); ?>" class="btn btn-danger" onclick="return(confirm('Anda Yakin ?'));"><i class="fa fa-trash"></i></a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
  </section>

  <div class="modal fade" id="tambaha" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Tambah Riwayat Perjalanan A</h5>
        </div>

        <form action="<?php echo e(url('/add_ripera')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

          <div class="modal-body">

              <?php $__currentLoopData = $idra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <input class="form-control" type="hidden" name="idaa" value="<?php echo e($ida->PERJ1_ID+1); ?>" required="">
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $pas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <input class="form-control" type="hidden" name="nik" value="<?php echo e($nia->NIK); ?>" required="">
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <div class="form-group">
                  <label>Negara</label>
                  <input type="text" name="neg" class="form-control" placeholder="Kanada" autocomplete="off" required="">
              </div>
              <div class="form-group">
                  <label>Kota</label>
                  <input type="text" name="kot" class="form-control" placeholder="Kediri" autocomplete="off" required="">
              </div>
              <div class="form-group">
                  <label>Tanggal Perjalanan</label>
                  <input type="date" name="tgp" class="form-control" autocomplete="off" required="">
              </div>
              <div class="form-group">
                  <label>Tanggal Tiba di Indonesia</label>
                  <input type="date" name="tgt" class="form-control" autocomplete="off" required="">
              </div>
          </div>
          <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
              <button class="btn btn-primary"><i class="fa fa-check-circle"></i> Simpan</button>
          </div>
        </form>

      </div>
    </div>
  </div>

  <?php $__currentLoopData = $rpa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="editRipera<?php echo e($ed->PERJ1_ID); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Edit Riwayat Perjalanan A</h5>
        </div>

        <?php 
            $id = $ed->PERJ1_ID;
            $upd = DB::SELECT("select*from r_perj1 where PERJ1_ID = '$id'");
        ?>
        <?php $__currentLoopData = $upd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/ripa:upd=<?php echo e($da->PERJ1_ID); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

        <div class="modal-body">
            <div class="form-group">
                <label>Negara</label>
                <input type="text" name="neg" class="form-control" value="<?php echo e($da->NEGARA); ?>" autocomplete="off" required="">
            </div>
            <div class="form-group">
                <label>Kota</label>
                <input type="text" name="kot" class="form-control" value="<?php echo e($da->KOTA); ?>" autocomplete="off" required="">
            </div>
            <div class="form-group">
                <label>Tanggal Perjalanan</label>
                <input type="date" name="tgp" class="form-control" value="<?php echo e($da->TGL_PERJ); ?>" autocomplete="off" required="">
            </div>
            <div class="form-group">
                <label>Tanggal Tiba di Indonesia</label>
                <input type="date" name="tgt" class="form-control" value="<?php echo e($da->TGL_TIBA); ?>" autocomplete="off" required="">
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
            <button class="btn btn-primary"><i class="fa fa-edit"></i> Ubah</button>
        </div>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


  <div class="modal fade" id="tambahb" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Tambah Riwayat Perjalanan B</h5>
        </div>

        <form action="<?php echo e(url('/add_riperb')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

          <div class="modal-body">

              <?php $__currentLoopData = $idrb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <input class="form-control" type="hidden" name="idaa" value="<?php echo e($idb->PERJ2_ID+1); ?>" required="">
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $pas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <input class="form-control" type="hidden" name="nik" value="<?php echo e($nib->NIK); ?>" required="">
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <div class="form-group">
                  <label>Provinsi</label>
                  <input type="text" name="pro" class="form-control" placeholder="Jawa Timur" autocomplete="off" required="">
              </div>
              <div class="form-group">
                  <label>Kota</label>
                  <input type="text" name="kot" class="form-control" placeholder="Kediri" autocomplete="off" required="">
              </div>
              <div class="form-group">
                  <label>Tanggal Perjalanan</label>
                  <input type="date" name="tgp" class="form-control" autocomplete="off" required="">
              </div>
              <div class="form-group">
                  <label>Tanggal Tiba di Indonesia</label>
                  <input type="date" name="tgt" class="form-control" autocomplete="off" required="">
              </div>
          </div>
          <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
              <button class="btn btn-primary"><i class="fa fa-check-circle"></i> Simpan</button>
          </div>
          </form>

      </div>
    </div>
  </div>

  <?php $__currentLoopData = $rpb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="editRiperb<?php echo e($ed->PERJ2_ID); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Edit Riwayat Perjalanan B</h5>
        </div>

        <?php 
            $id = $ed->PERJ2_ID;
            $upd = DB::SELECT("select*from r_perj2 where PERJ2_ID = '$id'");
        ?>
        <?php $__currentLoopData = $upd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/ripb:upd=<?php echo e($db->PERJ2_ID); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

            <div class="modal-body">
                <div class="form-group">
                    <label>Provinsi</label>
                    <input type="text" name="pro" class="form-control" value="<?php echo e($db->PROV); ?>" autocomplete="off" required="">
                </div>
                <div class="form-group">
                    <label>Kota</label>
                    <input type="text" name="kot" class="form-control" value="<?php echo e($db->KOTA); ?>" autocomplete="off" required="">
                </div>
                <div class="form-group">
                    <label>Tanggal Perjalanan</label>
                    <input type="date" name="tgp" class="form-control" value="<?php echo e($db->TGL_PERJ); ?>" autocomplete="off" required="">
                </div>
                <div class="form-group">
                    <label>Tanggal Tiba di Indonesia</label>
                    <input type="date" name="tgt" class="form-control" value="<?php echo e($db->TGL_TIBA); ?>" autocomplete="off" required="">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
                <button class="btn btn-primary"><i class="fa fa-edit"></i> Ubah</button>
            </div>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


  <div class="modal fade" id="tambahc" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Tambah Riwayat Perjalanan C</h5>
        </div>

        <form action="<?php echo e(url('/add_riperc')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

            <div class="modal-body">

                <?php $__currentLoopData = $idrc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input class="form-control" type="hidden" name="idaa" value="<?php echo e($idc->PERJ3_ID+1); ?>" required="">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $pas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input class="form-control" type="hidden" name="nik" value="<?php echo e($nic->NIK); ?>" required="">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="form-group">
                    <label>Provinsi</label>
                    <input type="text" name="pro" class="form-control" placeholder="Jawa Timur" autocomplete="off" required="">
                </div>
                <div class="form-group">
                    <label>Kota</label>
                    <input type="text" name="kot" class="form-control" placeholder="Kediri" autocomplete="off" required="">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
                <button class="btn btn-primary"><i class="fa fa-check-circle"></i> Simpan</button>
            </div>
        </form>

      </div>
    </div>
  </div>


  <?php $__currentLoopData = $rpc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="editRiperc<?php echo e($ed->PERJ3_ID); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Edit Riwayat Perjalanan C</h5>
        </div>

        <?php 

            $id = $ed->PERJ3_ID;
            $upd = DB::SELECT("select*from r_perj3 where PERJ3_ID = '$id'");

        ?>
        <?php $__currentLoopData = $upd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/ripc:upd=<?php echo e($dc->PERJ3_ID); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

            <div class="modal-body">
                <div class="form-group">
                    <label>Provinsi</label>
                    <input type="text" name="pro" class="form-control" value="<?php echo e($dc->PROV); ?>" autocomplete="off" required="">
                </div>
                <div class="form-group">
                    <label>Kota</label>
                    <input type="text" name="kot" class="form-control" value="<?php echo e($dc->KOTA); ?>" autocomplete="off" required="">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
                <button class="btn btn-primary"><i class="fa fa-edit"></i> Ubah</button>
            </div>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


  <div class="modal fade" id="tambahd" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Tambah Riwayat Perjalanan D</h5>
        </div>

        <form action="<?php echo e(url('/add_riperd')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

            <div class="modal-body">
                <?php $__currentLoopData = $idrd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input class="form-control" type="hidden" name="idaa" value="<?php echo e($idd->PERJ4_ID+1); ?>" required="">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $pas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input class="form-control" type="hidden" name="nik" value="<?php echo e($nid->NIK); ?>" required="">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" name="nam" class="form-control" placeholder="Ahmad" autocomplete="off" required="">
                </div>
                <div class="form-group">
                    <label>Alamat</label>
                    <input type="text" name="ala" class="form-control" placeholder="Jl. Mawar " autocomplete="off" required="">
                </div>
                <div class="form-group">
                    <label>Hubungan</label>
                    <input type="text" name="hub" class="form-control" placeholder="Teman Kerja" autocomplete="off" required="">
                </div>
                <div class="form-group">
                    <label>Tanggal Perjalanan</label>
                    <input type="date" name="tgp" class="form-control" autocomplete="off" required="">
                </div>
                <div class="form-group">
                    <label>Tanggal Tiba di Indonesia</label>
                    <input type="date" name="tgt" class="form-control" autocomplete="off" required="">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
                <button class="btn btn-primary"><i class="fa fa-check-circle"></i> Simpan</button>
            </div>
        </form>

      </div>
    </div>
  </div>


  <?php $__currentLoopData = $rpd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="editRiperd<?php echo e($ed->PERJ4_ID); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Edit Riwayat Perjalanan D</h5>
        </div>

        <?php 
            $id = $ed->PERJ4_ID;
            $upd = DB::SELECT("select*from r_perj4 where PERJ4_ID = '$id'");
        ?>
        <?php $__currentLoopData = $upd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/ripd:upd=<?php echo e($dd->PERJ4_ID); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

            <div class="modal-body">
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" name="nam" class="form-control" value="<?php echo e($dd->NAMA); ?>" autocomplete="off" required="">
                </div>
                <div class="form-group">
                    <label>Alamat</label>
                    <input type="text" name="ala" class="form-control" value="<?php echo e($dd->ALAMAT); ?>" autocomplete="off" required="">
                </div>
                <div class="form-group">
                    <label>Hubungan</label>
                    <input type="text" name="hub" class="form-control" value="<?php echo e($dd->HUBUNGAN); ?>" autocomplete="off" required="">
                </div>
                <div class="form-group">
                    <label>Tanggal Kontak Pertama</label>
                    <input type="date" name="tgp" class="form-control" value="<?php echo e($ed->TGL_AWAL); ?>" autocomplete="off" required="">
                </div>
                <div class="form-group">
                    <label>Tanggal Kontak Terakhir</label>
                    <input type="date" name="tgt" class="form-control" value="<?php echo e($dd->TGL_AKHIR); ?>" autocomplete="off" required="">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
                <button class="btn btn-primary"><i class="fa fa-edit"></i> Ubah</button>
            </div>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.laypetugas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pmpc\resources\views//petugas/det_riper.blade.php ENDPATH**/ ?>