<table>
    <thead>
        <tr>
            <td colspan="13" style="background-color:#c5c8c9;text-align: center; border: 1px solid #000000;">DATA PASIEN</td>
        </tr>
        <tr style="border: 1px solid #000000;">
            <th style="width: 20px; background-color: #5db9e3; border: 1px solid #000000; text-align: center;">NIK</th>
            <th style="width: 30px; background-color: #5db9e3; border: 1px solid #000000; text-align: center;">NAMA</th>
            <th style="width: 20px; background-color: #5db9e3; border: 1px solid #000000; text-align: center;">KECAMATAN</th>
            <th style="width: 20px; background-color: #5db9e3; border: 1px solid #000000; text-align: center;">KELURAHAN</th>
            <th style="width: 20px; background-color: #5db9e3; border: 1px solid #000000; text-align: center;">ORANG TUA</th>
            <th style="width: 20px; background-color: #5db9e3; border: 1px solid #000000; text-align: center;">TGL LAHIR</th>
            <th style="width: 20px; background-color: #5db9e3; border: 1px solid #000000; text-align: center;">USIA</th>
            <th style="width: 20px; background-color: #5db9e3; border: 1px solid #000000; text-align: center;">GENDER</th>
            <th style="width: 20px; background-color: #5db9e3; border: 1px solid #000000; text-align: center;">PEKERJAAN</th>
            <th style="width: 50px; background-color: #5db9e3; border: 1px solid #000000; text-align: center;">ALAMAT</th>
            <th style="width: 20px; background-color: #5db9e3; border: 1px solid #000000; text-align: center;">NO PONSEL</th>
            <th style="width: 20px; background-color: #5db9e3; border: 1px solid #000000; text-align: center;">KATEGORI</th>
            <th style="width: 50px; background-color: #5db9e3; border: 1px solid #000000; text-align: center;">KETERANGAN</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $hasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr style="border: 1px solid #000000;">
            <td style="border: 1px solid #000000;"><?php echo e($keg->NIK); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($keg->NAMA); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($keg->NAMA_KEC); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($keg->KELURAHAN); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($keg->NAMA_ORTU); ?></td>
            <td style="border: 1px solid #000000;"><?= date('d M Y',strtotime($keg->TGL_LAHIR)); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($keg->UMUR); ?> Tahun  <?php echo e($keg->UMUR); ?> Bulan</td>
            <td style="border: 1px solid #000000;"><?php echo e($keg->GENDER); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($keg->PEKERJAAN); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($keg->ALAMAT); ?> RT <?php echo e($keg->RT); ?>/ RW <?php echo e($keg->RW); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($keg->NO_TELP); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($keg->KAT); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($keg->KET); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>    

</table><?php /**PATH D:\xampp\htdocs\pmpc\resources\views/exports/cetak.blade.php ENDPATH**/ ?>