

<?php $__env->startSection('menu'); ?>
  <ul class="sidebar-menu">
    <li class="menu-header ">Main</li>
        <li class="dropdown">
          <a href="/petugas" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
        </li>
    <li class="menu-header">Data</li>
        <li class="dropdown active">
          <a href="#" class="nav-link"><i data-feather="users"></i><span>Data Pasien</span></a>
        </li>
        <li class="dropdown">
          <a href="/dataklinis" class="nav-link"><i data-feather="check-circle"></i><span>Data Informasi Klinis</span></a>
        </li>
        <li class="dropdown">
          <a href="/datapenunjang" class="nav-link"><i data-feather="check-circle"></i><span>Data Pemeriksaan Penunjang</span></a>
        </li>
        <li class="dropdown">
          <a href="/datariper" class="nav-link"><i data-feather="check-circle"></i><span>Data Riwayat Perjalanan</span></a>
        </li>
        <li class="dropdown">
          <a href="/datapaparan" class="nav-link"><i data-feather="check-circle"></i><span>Data Faktor Kontak / Paparan</span></a>
        </li>
    <li class="menu-header">Laporan</li>
        <li class="dropdown">
          <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="file-text"></i><span>Laporan</span></a>
          <ul class="dropdown-menu">
            <li><a class="nav-link" href="/datalaporanperhari">per Hari</a></li>
            <li><a class="nav-link" href="/datalaporanperbulan">per Bulan</a></li>
          </ul>
        </li>
  </ul>
<?php $__env->stopSection(); ?>
<?php 
    $no = 1;
    $gend = array('Laki-laki','Perempuan');
    $kat = array('Suspek','Kasus Probabel','Kasus Konfirmasi','Kontak Erat','ODR');
  ?>

<?php $__env->startSection('content'); ?>
  <section class="section">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h4>Data Kontak Erat<span style="color:red;">*</span></h4>
            </div>
            <div class="card-body">
              <div class="row">
                  <div class="col-md-6" style="margin-bottom: 20px;">
                      <a href="/datapasien" class="btn btn-success btn-block"><i class="fas fa-angle-double-left"></i> Kembali</a>  
                  </div>
                  <div class="col-md-6">
                      <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#exampleModalCenter"><i class="fas fa-plus-square"> </i> Tambah Kontak</button>
                  </div>
              </div>
              <div class="col-md-12">
              <table id="example" class="table table-striped table-bordered">
                  <thead>
                      <td>Nama </td>
                      <td>Umur</td>
                      <td>Gender</td>
                      <td>Hubungan</td>
                      <td>Alamat</td>
                      <td>No Ponsel</td>
                      <td>Aktivitas</td>
                      <td>Aksi</td>
                  </thead>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tbody>
                      <td><?php echo e($dat->NAMA); ?></td>
                      <td><?php echo e($dat->UMUR); ?> tahun</td>
                      <td><?php echo e($dat->GENDER); ?></td>
                      <td><?php echo e($dat->HUBUNGAN); ?></td>
                      <td><?php echo e($dat->ALAMAT); ?></td>
                      <td><?php echo e($dat->NO_TELP); ?></td>
                      <td><?php echo e($dat->AKTIVITAS); ?></td>
                      <td style="width: 110px;"> 
                          <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#editKontak<?php echo e($dat->KONTAK_ID); ?>"><i class="fas fa-edit"></i></a>
                          <a href="/kontak:del=<?php echo e($dat->KONTAK_ID); ?>" class="btn btn-danger" onclick="return(confirm('Anda Yakin ?'));"><i class="fas fa-trash"></i></a>
                      </td>
                  </tbody>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>
              </div>
            </div>
            <div class="card-footer" style="color: black;font-weight: bold;">
                Keterangan: <br>
                <span style="color:red;">*</span>) oksigenasi membran ekstrakorporea
            </div>
          </div>
        </div>
      </div>
  </section>

  <div class="modal fade" id="exampleModalCenter" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Tambah Kontak Erat</h5>
        </div>
        <form action="<?php echo e(url('/add_koner')); ?>" method="post" enctype="multidkrt/form-data">
              <?php echo e(csrf_field()); ?>

          <div class="modal-body">

              <?php $__currentLoopData = $idk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <input class="form-control" type="hidden" name="idk" value="<?php echo e($idk->KONTAK_ID+1); ?>" required="">
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $nid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <input class="form-control" type="hidden" name="nik" value="<?php echo e($nid->NIK); ?>" required="">
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <div class="form-group">
                  <label>Nama</label>
                  <input type="text" name="nam" class="form-control" placeholder="Ahmad" autocomplete="off" required="">
              </div>
              <div class="form-row">
                  <div class="form-group col-md-6">
                      <label for="inputEmail4">umur</label>
                      <input type="number" name="umur" class="form-control" min="1" autocomplete="off" required="">
                  </div>
                  <div class="form-group col-md-6">
                      <label for="inputPassword4">Gender</label>
                      <select name="gend" class="form-control" required="">
                          <option></option>
                          <?php $__currentLoopData = $gend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option><?php echo e($gen); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                  </div>
              </div>
              <div class="form-group">
                  <label>Hubungan</label>
                  <input type="text" name="hub" class="form-control" autocomplete="off" required="">
              </div> 
              <div class="form-group">
                  <label>Alamat</label>
                  <input type="text" name="alam" class="form-control" autocomplete="off" required="">
              </div>
              <div class="form-group">
                  <label>Nomor Ponsel yang bisa dihubungi</label>
                  <input type="text" name="no" class="form-control" autocomplete="off" required="">
              </div>
              <div class="form-group">
                  <label>Aktivitas</label>
                  <input type="text" name="akt" class="form-control" autocomplete="off" required="">
              </div>
          </div>
          <div class="modal-footer">
              <button  class="btn btn-danger" data-dismiss="modal"><i class="feather icon-x-circle"></i> Batal</button>
              <button class="btn btn-primary"><i class="feather icon-check-circle"></i> Simpan</button>
          </div>
      </form>
      </div>
    </div>
  </div>


  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="editKontak<?php echo e($upd->KONTAK_ID); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog modal-md" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Edit Kontak Erat</h5>
        </div>
        <?php 
            $id = $upd->KONTAK_ID;
            $ed = DB::SELECT("select*from kontak where KONTAK_ID = '$id'");
        ?>
        <?php $__currentLoopData = $ed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/kontak:upd=<?php echo e($ed->KONTAK_ID); ?>" method="post" enctype="multidkrt/form-data">
            <?php echo e(csrf_field()); ?>

        <div class="modal-body">
            <div class="form-group">
                <label>Nama</label>
                <input type="text" name="nam" class="form-control" value="<?php echo e($ed->NAMA); ?>" autocomplete="off" required="">
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="inputEmail4">umur</label>
                    <input type="number" name="umur" class="form-control" min="1" max="60" value="<?php echo e($ed->UMUR); ?>" placeholder="1 - 60 tahun" autocomplete="off" required="">
                </div>
                <div class="form-group col-md-6">
                    <label for="inputPassword4">Gender</label>
                    <select name="gend" class="form-control" required="">
                        <option></option>
                        <?php $__currentLoopData = $gend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if ($ge == $ed->GENDER){ ?>
                               <option value="<?php echo e($ge); ?>" selected=""><?php echo e($ge); ?></option>
                            <?php }else{ ?>
                              <option value="<?php echo e($ge); ?>"><?php echo e($ge); ?></option>
                            <?php }?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>Hubungan</label>
                <input type="text" name="hub" class="form-control" value="<?php echo e($ed->HUBUNGAN); ?>" autocomplete="off" required="">
            </div> 
            <div class="form-group">
                <label>Alamat</label>
                <input type="text" name="alam" class="form-control" value="<?php echo e($ed->ALAMAT); ?>" autocomplete="off" required="">
            </div>
            <div class="form-group">
                <label>Nomor Ponsel yang bisa dihubungi</label>
                <input type="text" name="no" class="form-control" value="<?php echo e($ed->NO_TELP); ?>" autocomplete="off" required="">
            </div>
            <div class="form-group">
                <label>Aktivitas</label>
                <input type="text" name="akt" class="form-control" value="<?php echo e($ed->AKTIVITAS); ?>" autocomplete="off" required="">
            </div>
        </div>
        <div class="modal-footer">
            <button  class="btn btn-danger" data-dismiss="modal"><i class="feather icon-x-circle"></i> Batal</button>
            <button class="btn btn-primary"><i class="feather icon-check-circle"></i> Ubah</button>
        </div>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     </div>
      </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.laypetugas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\si_pendataan_dan_monitoring_pasien_covid\resources\views//petugas/dt_kontakerat.blade.php ENDPATH**/ ?>