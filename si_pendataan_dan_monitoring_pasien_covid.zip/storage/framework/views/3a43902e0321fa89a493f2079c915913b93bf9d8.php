

<?php $__env->startSection('menu'); ?>
  <ul class="sidebar-menu">
    <li class="menu-header ">Main</li>
    <li class="dropdown">
      <a href="/petugas" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
    </li>
    <li class="menu-header">Data</li>
    <li class="dropdown">
      <a href="/datapasien" class="nav-link"><i data-feather="users"></i><span>Data Pasien</span></a>
    </li>
    <li class="dropdown">
      <a href="/dataklinis" class="nav-link"><i data-feather="check-circle"></i><span>Data Informasi Klinis</span></a>
    </li>
    <li class="dropdown active">
      <a href="#" class="nav-link"><i data-feather="check-circle"></i><span>Data Pemeriksaan Penunjang</span></a>
    </li>
    <li class="dropdown">
      <a href="/datariper" class="nav-link"><i data-feather="check-circle"></i><span>Data Riwayat Perjalanan</span></a>
    </li>
    <li class="dropdown">
      <a href="/datapaparan" class="nav-link"><i data-feather="check-circle"></i><span>Data Faktor Kontak / Paparan</span></a>
    </li>
  </ul>
<?php $__env->stopSection(); ?>
<?php 
    $no = 1;
    $has = array('','Positif','Negatif');
    $has2 = array('','Reaktif','Non Reaktif');
  ?>

<?php $__env->startSection('content'); ?>
  <section class="section">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h4>Data Pemeriksaan Penunjang</h4>
            </div>
            <div class="card-body">
              <a href="#" class="btn btn-icon icon-left btn-primary" data-toggle="modal" data-target="#exampleModalCenter"  style="margin-bottom: 10px;"><i class="fas fa-plus-square"></i> Tambah Data Pemeriksaan Penunjang</a>
              <div class="table-responsive">
                <table class="table table-striped table-hover" id="save-stage" style="width: 100%;">
                  <thead>
                      <tr>
                          <th>NIK</th>
                          <th>Nama</th>
                          <th>Gender</th>
                          <th>Pekerjaan</th>
                          <th>Aksi</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <td><?php echo e($no++); ?></td>
                          <td><?php echo e($dat->NAMA); ?></td>
                          <td><?php echo e($dat->GENDER); ?></td>
                          <td><?php echo e($dat->PEKERJAAN); ?></td>
                          <td style="width: 150px;">
                              <a href="#" class="btn btn-info" data-toggle="modal" data-target="#infoPenunjang<?php echo e($dat->PENJ_ID); ?>"><i class="fa fa-info-circle"></i></a>
                              <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#editPenunjang<?php echo e($dat->PENJ_ID); ?>"><i class="fa fa-edit"></i></a>
                              <a href="/pen:del=<?php echo e($dat->PENJ_ID); ?>" class="btn btn-danger" onclick="return(confirm('Anda Yakin ?'));"><i class="fa fa-trash"></i></a>
                          </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
  </section>

  <div class="modal fade" id="exampleModalCenter" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Tambah Pemeriksaan Penunjang</h5>
        </div>
        <form action="<?php echo e(url('/add_penunjang')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>


        <div class="modal-body">
            <div class="row">
                <div class="col-md-12">
                    <!-- <h6 style="padding-top:-10px;text-align: center;">Spesimen</h6><br> -->
                    <style type="text/css">
                        table tr td{
                            padding: 5px;
                        }
                    </style>
                      <?php $__currentLoopData = $idp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <input type="hidden" name="idp" class="form-control" value="<?php echo e($id->PENJ_ID+1); ?>" readonly="">
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <table>
                          <tr>
                              <td>NOMOR INDUK KEPENDUDUKAN</td>
                              <td>:</td>
                              <td style="width: 65%;">
                                <select class="form-control select2" name="nik" required="" style="width: 100%;">
                                  <option></option>
                                  <?php $__currentLoopData = $pas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($pa->NIK); ?>"><?php echo e($pa->NAMA); ?> / <?php echo e($pa->NIK); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </td>
                          </tr>
                      </table>
                      <br>
                      <table border="" style="width: 100%;">
                          <tr>
                              <td rowspan="2">Jenis Pemeriksaan / Spesimen</td>
                              <td colspan="3" style="text-align: center;">Pengambilan Spesimen</td>
                          </tr>
                          <tr>
                              <td style="text-align: center;">Tanggal Pengambilan</td>
                              <td style="text-align: center;">Tempat Pemeriksaan</td>
                              <td style="text-align: center;">Hasil</td>
                          </tr>
                          <tr>
                              <td colspan="4" style="background-color: lightgrey;">Laboratorium Konfirmasi</td>
                          </tr>
                          <tr>
                              <td style="width: 235px;"><input type="text" name="jn1" class="form-control" placeholder="sebutkan" autocomplete="off" value="Nasopharyngeal (NP) Swab" style="border:none;background-color: white;" readonly=""></td>
                              <td><input type="date" name="tg1" class="form-control" style="width: 160px;"></td>
                              <td>
                                  <select name="tp1" class="form-control select2" style="width: 200px;">
                                    <option></option>
                                    <?php $__currentLoopData = $tmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                              </td>
                              <td>
                                  <select name="hs1" class="form-control">
                                      <?php $__currentLoopData = $has; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option><?php echo e($ha); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                              </td>
                          </tr>
                          <tr>
                              <td style="width: 235px;"><input type="text" name="jn2" class="form-control" placeholder="sebutkan" autocomplete="off" value="Oropharyngeal (NP) Swab" style="border:none;background-color: white;" readonly=""></td>
                              <td><input type="date" name="tg2" class="form-control" style="width: 160px;"  ></td>
                              <td>
                                  <select name="tp2" class="form-control select2" style="width: 200px;">
                                    <option></option>
                                    <?php $__currentLoopData = $tmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                              </td>
                              <td>
                                  <select name="hs2" class="form-control">
                                      <?php $__currentLoopData = $has; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option><?php echo e($ha); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                              </td>
                          </tr>
                          <tr>
                              <td style="width: 235px;"><input type="text" name="jn3" class="form-control" placeholder="sebutkan" autocomplete="off" value="Sputum" style="border:none;background-color: white;" readonly=""></td>
                              <td><input type="date" name="tg3" class="form-control" style="width: 160px;"  ></td>
                              <td>
                                  <select name="tp3" class="form-control select2" style="width: 200px;">
                                    <option></option>
                                    <?php $__currentLoopData = $tmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                              </td>
                              <td>
                                  <input type="text" name="hs3" class="form-control" autocomplete="off">
                              </td>
                          </tr>
                          <tr>
                              <td style="width: 235px;"><input type="text" name="jn4" class="form-control" placeholder="sebutkan" autocomplete="off" value="Serum" style="border:none;background-color: white;" readonly=""></td>
                              <td><input type="date" name="tg4" class="form-control" style="width: 160px;"  ></td>
                              <td>
                                  <select name="tp4" class="form-control select2" style="width: 200px;">
                                    <option></option>
                                    <?php $__currentLoopData = $tmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                              </td>
                              <td>
                                  <input type="text" name="hs4" class="form-control" autocomplete="off">
                              </td>
                          </tr>
                          <tr>
                              <td colspan="4" style="background-color: lightgrey;">Pemeriksaan Lain</td>
                          </tr>
                          <tr>
                              <td style="width: 235px;"><input type="text" name="jn5" class="form-control" placeholder="sebutkan" autocomplete="off" value="Rapid Antigen" style="border:none;background-color: white;" readonly=""></td>
                              <td><input type="date" name="tg5" class="form-control" style="width: 160px;"  ></td>
                              <td>
                                  <select name="tp5" class="form-control select2" style="width: 200px;">
                                    <option></option>
                                    <?php $__currentLoopData = $tmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                              </td>
                              <td>
                                  <select name="hs5" class="form-control">
                                      <?php $__currentLoopData = $has; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option><?php echo e($ha); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                              </td>
                          </tr>
                          <tr>
                              <td style="width: 235px;"><input type="text" name="jn6" class="form-control" placeholder="sebutkan" autocomplete="off" value="Rapid Antibody" style="border:none;background-color: white;" readonly=""></td>
                              <td><input type="date" name="tg6" class="form-control" style="width: 160px;"  ></td>
                              <td>
                                  <select name="tp6" class="form-control select2" style="width: 200px;">
                                    <option></option>
                                    <?php $__currentLoopData = $tmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                              </td>
                              <td>
                                  <select name="hs6" class="form-control">
                                      <?php $__currentLoopData = $has2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ha2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option><?php echo e($ha2); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                              </td>
                          </tr>
                          <tr>
                              <td style="width: 235px;"><input type="text" name="jn7" class="form-control" autocomplete="off" placeholder="Lainnya ..."></td>
                              <td><input type="date" name="tg7" class="form-control" style="width: 160px;"></td>
                              <td>
                                  <select name="tp7" class="form-control select2" style="width: 200px;">
                                    <option></option>
                                    <?php $__currentLoopData = $tmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                              </td>
                              <td>
                                  <input type="text" name="hs7" class="form-control">
                              </td>
                          </tr>
                      </table>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button  class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
            <button class="btn btn-primary"><i class="fa fa-check-circle"></i> Simpan</button>
        </div>
        </form>
      </div>
    </div>
  </div>


  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="infoPenunjang<?php echo e($info->PENJ_ID); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Info Pemeriksaan Penunjang</h5>
        </div>
        <?php
            $id = $info->PENJ_ID;
            $in = DB::SELECT("select*from p_penunjang  where PENJ_ID = '$id'");
        ?>
        <?php $__currentLoopData = $in; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal-body">
            <div class="row">
                <div class="col-md-12">
                    <style type="text/css">
                        
                        table tr td{
                            padding: 5px;
                        }

                    </style>
                    <table border="" style="width: 100%;text-align: center;">
                        <tr>
                            <td rowspan="2">Jenis Pemeriksaan / Spesimen</td>
                            <td colspan="3" style="text-align: center;">Pengambilan Spesimen</td>
                        </tr>
                        <tr>
                            <td style="text-align: center;">Tanggal Pengambilan</td>
                            <td style="text-align: center;">Tempat Pemeriksaan</td>
                            <td style="text-align: center;">Hasil</td>
                        </tr>
                        <tr>
                            <td colspan="4" style="background-color: lightgrey;text-align: left;">Laboratorium Konfirmasi</td>
                        </tr>
                        <tr>
                            <td style="width: 235px;">
                                <input type="text" name="jn1" class="form-control" placeholder="sebutkan" autocomplete="off" value="Nasopharyngeal (NP) Swab" style="border:none;background-color: white;" readonly="">
                            </td>
                            <td>
                              <?php
                                if($det->TGLA == null){
                                    echo "";
                                }else{
                                    echo date('d M Y',strtotime($det->TGLA));
                                }
                              ?>
                            </td>
                            <td>
                            <?php 
                                $tmpa = DB::SELECT("select*from tempat_pemeriksaan where TMP_ID = '$det->TMPA' ");
                                foreach($tmpa as $tm){ 
                                  echo $tm->NAMA_TEMPAT;
                                }
                            ?>
                            </td>
                            <td><?php echo e($det->HSLA); ?></td>
                        </tr>
                        <tr>
                            <td style="width: 235px;"><input type="text" name="jn2" class="form-control" placeholder="sebutkan" autocomplete="off" value="Oropharyngeal (NP) Swab" style="border:none;background-color: white;" readonly=""></td>
                            <td><?php
                                    if($det->TGLB == null){
                                        echo "";
                                    }else{
                                        echo date('d M Y',strtotime($det->TGLB));
                                    }
                                ?>
                            </td>
                            <td>
                            <?php 
                                $tmpa = DB::SELECT("select*from tempat_pemeriksaan where TMP_ID = '$det->TMPB' ");
                                foreach($tmpa as $tm){ 
                                  echo $tm->NAMA_TEMPAT;
                                }
                            ?>
                            </td>
                            <td><?php echo e($det->HSLB); ?></td>
                        </tr>
                        <tr>
                            <td style="width: 235px;"><input type="text" name="jn3" class="form-control" placeholder="sebutkan" autocomplete="off" value="Sputum" style="border:none;background-color: white;" readonly=""></td>
                            <td>
                                <?php
                                    if($det->TGLC == null){
                                        echo "";
                                    }else{
                                        echo date('d M Y',strtotime($det->TGLC));
                                    }
                                ?>
                            </td>
                            <td>
                            <?php 
                                $tmpa = DB::SELECT("select*from tempat_pemeriksaan where TMP_ID = '$det->TMPC' ");
                                foreach($tmpa as $tm){ 
                                  echo $tm->NAMA_TEMPAT;
                                }
                            ?>
                            </td>
                            <td><?php echo e($det->HSLC); ?></td>
                        </tr>
                        <tr>
                            <td style="width: 235px;"><input type="text" name="jn4" class="form-control" placeholder="sebutkan" autocomplete="off" value="Serum" style="border:none;background-color: white;" readonly=""></td>
                            <td>
                                <?php
                                    if($det->TGLD == null){
                                        echo "";
                                    }else{
                                        echo date('d M Y',strtotime($det->TGLD));
                                    }
                                ?>
                            </td>
                            <td>
                            <?php 
                                $tmpa = DB::SELECT("select*from tempat_pemeriksaan where TMP_ID = '$det->TMPD' ");
                                foreach($tmpa as $tm){ 
                                  echo $tm->NAMA_TEMPAT;
                                }
                            ?>
                            </td>
                            <td><?php echo e($det->HSLD); ?></td>
                        </tr>
                        <tr>
                            <td colspan="4" style="background-color: lightgrey;text-align: left;">Pemeriksaan Lain</td>
                        </tr>
                        <tr>
                            <td style="width: 235px;"><input type="text" name="jn5" class="form-control" placeholder="sebutkan" autocomplete="off" value="Rapid Antigen" style="border:none;background-color: white;" readonly=""></td>
                            <td>
                                <?php
                                    if($det->TGLE == null){
                                        echo "";
                                    }else{
                                        echo date('d M Y',strtotime($det->TGLE));
                                    }
                                ?>
                            </td>
                            <td>
                            <?php 
                                $tmpa = DB::SELECT("select*from tempat_pemeriksaan where TMP_ID = '$det->TMPE' ");
                                foreach($tmpa as $tm){ 
                                  echo $tm->NAMA_TEMPAT;
                                }
                            ?>
                            </td>
                            <td><?php echo e($det->HSLE); ?></td>
                        </tr>
                        <tr>
                            <td style="width: 235px;"><input type="text" name="jn6" class="form-control" placeholder="sebutkan" autocomplete="off" value="Rapid Antibody" style="border:none;background-color: white;" readonly=""></td>
                            <td>
                                <?php
                                    if($det->TGLF == null){
                                        echo "";
                                    }else{
                                        echo date('d M Y',strtotime($det->TGLF));
                                    }
                                ?>
                            </td>
                            <td>
                            <?php 
                                $tmpa = DB::SELECT("select*from tempat_pemeriksaan where TMP_ID = '$det->TMPF' ");
                                foreach($tmpa as $tm){ 
                                  echo $tm->NAMA_TEMPAT;
                                }
                            ?>
                            </td>
                            <td><?php echo e($det->HSLF); ?></td>
                        </tr>
                        <tr>
                            <td style="width: 235px;"><input type="text" name="jn2" class="form-control"  autocomplete="off" value="<?php echo e($det->JNG); ?>" style="border:none;background-color: white;" readonly=""></td>
                            <td>
                                <?php
                                    if($det->TGLG == null){
                                        echo "";
                                    }else{
                                        echo date('d M Y',strtotime($det->TGLG));
                                    }
                                ?>
                            </td>
                            <td>
                            <?php 
                                $tmpa = DB::SELECT("select*from tempat_pemeriksaan where TMP_ID = '$det->TMPG' ");
                                foreach($tmpa as $tm){ 
                                  echo $tm->NAMA_TEMPAT;
                                }
                            ?>
                            </td>
                            <td><?php echo e($det->HSLG); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="modal-footer">
            <button  class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times-circle"></i> Tutup</button>
        </div>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="editPenunjang<?php echo e($edit->PENJ_ID); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenterTitle">Info Pemeriksaan Penunjang</h5>
        </div>
        <?php
            $id = $edit->PENJ_ID;
            $ed = DB::SELECT("select*from p_penunjang where PENJ_ID = '$id'");
            $tmp = DB::SELECT("select*from tempat_pemeriksaan");
        ?>
        <?php $__currentLoopData = $ed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/pen:upd=<?php echo e($upd->PENJ_ID); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>


        <div class="modal-body">
        <div class="col-md-12">
            <div class="row">
                <table border="" style="width: 100%;">
                        <tr>
                            <td rowspan="2">Jenis Pemeriksaan / Spesimen</td>
                            <td colspan="3" style="text-align: center;">Pengambilan Spesimen</td>
                        </tr>
                        <tr>
                            <td style="text-align: center;">Tanggal Pengambilan</td>
                            <td style="text-align: center;width: 200px;">Tempat Pemeriksaan</td>
                            <td style="text-align: center;">Hasil</td>
                        </tr>
                        <tr>
                            <td colspan="4" style="background-color: lightgrey;">Laboratorium Konfirmasi</td>
                        </tr>
                        <tr>
                            <td style="width: 235px;"><input type="text" name="jn1" class="form-control" placeholder="sebutkan" autocomplete="off" value="Nasopharyngeal (NP) Swab" style="border:none;background-color: white;" readonly=""></td>
                            <td><input type="date" name="tg1" class="form-control" style="width: 160px;" value="<?php echo e($upd->TGLA); ?>"></td>
                            <td>
                                <select class="form-control select2" name="tp1" style="width: 200px;">
                                    <?php
                                      if($upd->TMPA == null){
                                    ?>
                                        <option></option>
                                        <?php $__currentLoopData = $tmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                      }else{
                                          foreach($tmp as $tm){
                                            if ($tm->TMP_ID == $upd->TMPA){ ?>
                                              <option value="<?php echo e($tm->TMP_ID); ?>" selected=""><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                            <?php }else{ ?>
                                              <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                            <?php } 
                                          }
                                      }
                                    ?>
                                </select>
                            </td>
                            <td>
                                <select class="form-control" name="hs1">
                                  <?php $__currentLoopData = $has; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if ($ha == $upd->HSLA){ ?>
                                       <option selected=""><?php echo e($ha); ?></option>
                                    <?php }else{ ?>
                                      <option><?php echo e($ha); ?></option>
                                    <?php }?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 235px;"><input type="text" name="jn2" class="form-control" placeholder="sebutkan" autocomplete="off" value="Oropharyngeal (NP) Swab" style="border:none;background-color: white;" readonly=""></td>
                            <td><input type="date" name="tg2" class="form-control" style="width: 160px;" value="<?php echo e($upd->TGLB); ?>"></td>
                            <td>
                                <select class="form-control select2" name="tp2" style="width: 200px;">
                                    <?php
                                        if($upd->TMPB == null){
                                    ?>
                                          <option></option>
                                          <?php $__currentLoopData = $tmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        }else{
                                            foreach($tmp as $tm){
                                              if ($tm->TMP_ID == $upd->TMPB){ ?>
                                                <option value="<?php echo e($tm->TMP_ID); ?>" selected=""><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                              <?php }else{ ?>
                                                <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                              <?php } 
                                            }
                                        }
                                    ?>
                                </select>
                            </td>
                            <td>
                                <select class="form-control" name="hs2">
                                  <?php $__currentLoopData = $has; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if ($ha == $upd->HSLB){ ?>
                                       <option selected=""><?php echo e($ha); ?></option>
                                    <?php }else{ ?>
                                      <option><?php echo e($ha); ?></option>
                                    <?php }?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 235px;"><input type="text" name="jn3" class="form-control" placeholder="sebutkan" autocomplete="off" value="Sputum" style="border:none;background-color: white;" readonly=""></td>
                            <td><input type="date" name="tg3" class="form-control" style="width: 160px;" value="<?php echo e($upd->TGLC); ?>"></td>
                            <td>
                                <select class="form-control select2" name="tp3" style="width: 200px;">
                                  <?php
                                      if($upd->TMPC == null){
                                  ?>
                                        <option></option>
                                        <?php $__currentLoopData = $tmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php
                                      }else{
                                          foreach($tmp as $tm){
                                            if ($tm->TMP_ID == $upd->TMPC){ ?>
                                              <option value="<?php echo e($tm->TMP_ID); ?>" selected=""><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                            <?php }else{ ?>
                                              <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                            <?php } 
                                          }
                                      }
                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="hs3" class="form-control" value="<?php echo e($upd->HSLC); ?>">
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 235px;"><input type="text" name="jn4" class="form-control" placeholder="sebutkan" autocomplete="off" value="Serum" style="border:none;background-color: white;" readonly=""></td>
                            <td><input type="date" name="tg4" class="form-control" style="width: 160px;" value="<?php echo e($upd->TGLD); ?>"></td>
                            <td>
                                <select class="form-control select2" name="tp4" style="width: 200px;">
                                  <?php
                                      if($upd->TMPD == null){
                                  ?>
                                        <option></option>
                                        <?php $__currentLoopData = $tmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php
                                      }else{
                                          foreach($tmp as $tm){
                                            if ($tm->TMP_ID == $upd->TMPD){ ?>
                                              <option value="<?php echo e($tm->TMP_ID); ?>" selected=""><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                            <?php }else{ ?>
                                              <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                            <?php } 
                                          }
                                      }
                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="hs4" class="form-control" value="<?php echo e($upd->HSLD); ?>">
                            </td>
                        </tr>
                        <tr>
                            <td colspan="4" style="background-color: lightgrey;">Pemeriksaan Lain</td>
                        </tr>
                        <tr>
                            <td style="width: 235px;"><input type="text" name="jn5" class="form-control" placeholder="sebutkan" autocomplete="off" value="Rapid Antigen" style="border:none;background-color: white;" readonly=""></td>
                             <td><input type="date" name="tg5" class="form-control" style="width: 160px;" value="<?php echo e($upd->TGLE); ?>"></td>
                            <td>
                                <select class="form-control select2" name="tp5" style="width: 200px;">
                                  <?php
                                      if($upd->TMPE == null){
                                  ?>
                                        <option></option>
                                        <?php $__currentLoopData = $tmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php
                                      }else{
                                          foreach($tmp as $tm){
                                            if ($tm->TMP_ID == $upd->TMPE){ ?>
                                              <option value="<?php echo e($tm->TMP_ID); ?>" selected=""><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                            <?php }else{ ?>
                                              <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                            <?php } 
                                          }
                                      }
                                  ?>
                                </select>
                            </td>
                            <td>
                                <select class="form-control" name="hs5">
                                  <?php $__currentLoopData = $has; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if ($ha == $upd->HSLE){ ?>
                                       <option selected=""><?php echo e($ha); ?></option>
                                    <?php }else{ ?>
                                      <option><?php echo e($ha); ?></option>
                                    <?php }?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 235px;"><input type="text" name="jn6" class="form-control" placeholder="sebutkan" autocomplete="off" value="Rapid Antibody" style="border:none;background-color: white;" readonly=""></td>
                             <td><input type="date" name="tg6" class="form-control" style="width: 160px;" value="<?php echo e($upd->TGLF); ?>"></td>
                            <td>
                                <select class="form-control select2" name="tp6" style="width: 200px;">
                                  <?php
                                      if($upd->TMPF == null){
                                  ?>
                                        <option></option>
                                        <?php $__currentLoopData = $tmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php
                                      }else{
                                          foreach($tmp as $tm){
                                            if ($tm->TMP_ID == $upd->TMPF){ ?>
                                              <option value="<?php echo e($tm->TMP_ID); ?>" selected=""><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                            <?php }else{ ?>
                                              <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                            <?php } 
                                          }
                                      }
                                  ?>
                                </select>
                            </td>
                            <td>
                                <select class="form-control" name="hs6">
                                  <?php $__currentLoopData = $has2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ha2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if ($ha2 == $upd->HSLF){ ?>
                                       <option selected=""><?php echo e($ha2); ?></option>
                                    <?php }else{ ?>
                                      <option><?php echo e($ha2); ?></option>
                                    <?php }?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 235px;"><input type="text" name="jn7" class="form-control" autocomplete="off" value="<?php echo e($upd->JNG); ?>"></td>
                            <td><input type="date" name="tg7" class="form-control" style="width: 160px;" value="<?php echo e($upd->TGLG); ?>"></td>
                            <td>
                              <select class="form-control select2" name="tp7" style="width: 200px;">
                                  <?php
                                    if($upd->TMPG == null){
                                  ?>
                                      <option></option>
                                      <?php $__currentLoopData = $tmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php
                                    }else{
                                        foreach($tmp as $tm){
                                          if ($tm->TMP_ID == $upd->TMPG){ ?>
                                            <option value="<?php echo e($tm->TMP_ID); ?>" selected=""><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                          <?php }else{ ?>
                                            <option value="<?php echo e($tm->TMP_ID); ?>"><?php echo e($tm->NAMA_TEMPAT); ?></option>
                                          <?php } 
                                        }
                                    }
                                  ?>
                                </select>
                              </td>
                            <td>
                                <input type="text" name="hs7" class="form-control" value="<?php echo e($upd->HSLG); ?>">
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button  class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
            <button class="btn btn-primary"><i class="fa fa-edit"></i> Ubah</button>
        </div>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <script type="text/javascript">

      function verifyAnswer() {  
          //get the selected value from the dropdown list  
          var mylist = document.getElementById("trs");  
          var result = mylist.options[mylist.selectedIndex].text;  
            if (result == 'Tidak') {  
              //disable all the radio button   
              document.getElementById("nars").disabled = true;  
              document.getElementById("tgrs").disabled = true;   
            } else {  
              //enable all the radio button  
              document.getElementById("nars").disabled = false;  
              document.getElementById("tgrs").disabled = false;   
            }  
          } 
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.laypetugas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pmpc2\resources\views//petugas/dt_penunjang.blade.php ENDPATH**/ ?>